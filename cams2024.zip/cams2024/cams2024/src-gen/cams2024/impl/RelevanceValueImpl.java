/**
 */
package cams2024.impl;

import cams2024.Cams2024Package;
import cams2024.RelValue;
import cams2024.RelevanceValue;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Relevance Value</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link cams2024.impl.RelevanceValueImpl#getValue_or_range <em>Value or range</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RelevanceValueImpl extends MinimalEObjectImpl.Container implements RelevanceValue {
	/**
	 * The default value of the '{@link #getValue_or_range() <em>Value or range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue_or_range()
	 * @generated
	 * @ordered
	 */
	protected static final RelValue VALUE_OR_RANGE_EDEFAULT = RelValue.LOW;

	/**
	 * The cached value of the '{@link #getValue_or_range() <em>Value or range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue_or_range()
	 * @generated
	 * @ordered
	 */
	protected RelValue value_or_range = VALUE_OR_RANGE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RelevanceValueImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cams2024Package.Literals.RELEVANCE_VALUE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RelValue getValue_or_range() {
		return value_or_range;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setValue_or_range(RelValue newValue_or_range) {
		RelValue oldValue_or_range = value_or_range;
		value_or_range = newValue_or_range == null ? VALUE_OR_RANGE_EDEFAULT : newValue_or_range;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cams2024Package.RELEVANCE_VALUE__VALUE_OR_RANGE,
					oldValue_or_range, value_or_range));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cams2024Package.RELEVANCE_VALUE__VALUE_OR_RANGE:
			return getValue_or_range();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cams2024Package.RELEVANCE_VALUE__VALUE_OR_RANGE:
			setValue_or_range((RelValue) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cams2024Package.RELEVANCE_VALUE__VALUE_OR_RANGE:
			setValue_or_range(VALUE_OR_RANGE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cams2024Package.RELEVANCE_VALUE__VALUE_OR_RANGE:
			return value_or_range != VALUE_OR_RANGE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (value_or_range: ");
		result.append(value_or_range);
		result.append(')');
		return result.toString();
	}

} //RelevanceValueImpl
