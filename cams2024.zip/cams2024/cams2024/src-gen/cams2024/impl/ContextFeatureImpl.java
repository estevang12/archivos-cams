/**
 */
package cams2024.impl;

import cams2024.AbstractSensor;
import cams2024.Cams2024Package;
import cams2024.ContextFeature;
import cams2024.RelevanceValue;
import cams2024.Rule;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Context Feature</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link cams2024.impl.ContextFeatureImpl#getObserver <em>Observer</em>}</li>
 *   <li>{@link cams2024.impl.ContextFeatureImpl#getName <em>Name</em>}</li>
 *   <li>{@link cams2024.impl.ContextFeatureImpl#getLatitud <em>Latitud</em>}</li>
 *   <li>{@link cams2024.impl.ContextFeatureImpl#getLongitud <em>Longitud</em>}</li>
 *   <li>{@link cams2024.impl.ContextFeatureImpl#getHas_abstractsensor <em>Has abstractsensor</em>}</li>
 *   <li>{@link cams2024.impl.ContextFeatureImpl#getHas_relevancevalue <em>Has relevancevalue</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ContextFeatureImpl extends MinimalEObjectImpl.Container implements ContextFeature {
	/**
	 * The cached value of the '{@link #getObserver() <em>Observer</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObserver()
	 * @generated
	 * @ordered
	 */
	protected EList<Rule> observer;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getLatitud() <em>Latitud</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLatitud()
	 * @generated
	 * @ordered
	 */
	protected static final double LATITUD_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getLatitud() <em>Latitud</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLatitud()
	 * @generated
	 * @ordered
	 */
	protected double latitud = LATITUD_EDEFAULT;

	/**
	 * The default value of the '{@link #getLongitud() <em>Longitud</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLongitud()
	 * @generated
	 * @ordered
	 */
	protected static final double LONGITUD_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getLongitud() <em>Longitud</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLongitud()
	 * @generated
	 * @ordered
	 */
	protected double longitud = LONGITUD_EDEFAULT;

	/**
	 * The cached value of the '{@link #getHas_abstractsensor() <em>Has abstractsensor</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHas_abstractsensor()
	 * @generated
	 * @ordered
	 */
	protected EList<AbstractSensor> has_abstractsensor;

	/**
	 * The cached value of the '{@link #getHas_relevancevalue() <em>Has relevancevalue</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHas_relevancevalue()
	 * @generated
	 * @ordered
	 */
	protected EList<RelevanceValue> has_relevancevalue;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ContextFeatureImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cams2024Package.Literals.CONTEXT_FEATURE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Rule> getObserver() {
		if (observer == null) {
			observer = new EObjectResolvingEList<Rule>(Rule.class, this, Cams2024Package.CONTEXT_FEATURE__OBSERVER);
		}
		return observer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cams2024Package.CONTEXT_FEATURE__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getLatitud() {
		return latitud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLatitud(double newLatitud) {
		double oldLatitud = latitud;
		latitud = newLatitud;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cams2024Package.CONTEXT_FEATURE__LATITUD, oldLatitud,
					latitud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getLongitud() {
		return longitud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLongitud(double newLongitud) {
		double oldLongitud = longitud;
		longitud = newLongitud;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cams2024Package.CONTEXT_FEATURE__LONGITUD,
					oldLongitud, longitud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<AbstractSensor> getHas_abstractsensor() {
		if (has_abstractsensor == null) {
			has_abstractsensor = new EObjectContainmentEList<AbstractSensor>(AbstractSensor.class, this,
					Cams2024Package.CONTEXT_FEATURE__HAS_ABSTRACTSENSOR);
		}
		return has_abstractsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<RelevanceValue> getHas_relevancevalue() {
		if (has_relevancevalue == null) {
			has_relevancevalue = new EObjectContainmentEList<RelevanceValue>(RelevanceValue.class, this,
					Cams2024Package.CONTEXT_FEATURE__HAS_RELEVANCEVALUE);
		}
		return has_relevancevalue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cams2024Package.CONTEXT_FEATURE__HAS_ABSTRACTSENSOR:
			return ((InternalEList<?>) getHas_abstractsensor()).basicRemove(otherEnd, msgs);
		case Cams2024Package.CONTEXT_FEATURE__HAS_RELEVANCEVALUE:
			return ((InternalEList<?>) getHas_relevancevalue()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cams2024Package.CONTEXT_FEATURE__OBSERVER:
			return getObserver();
		case Cams2024Package.CONTEXT_FEATURE__NAME:
			return getName();
		case Cams2024Package.CONTEXT_FEATURE__LATITUD:
			return getLatitud();
		case Cams2024Package.CONTEXT_FEATURE__LONGITUD:
			return getLongitud();
		case Cams2024Package.CONTEXT_FEATURE__HAS_ABSTRACTSENSOR:
			return getHas_abstractsensor();
		case Cams2024Package.CONTEXT_FEATURE__HAS_RELEVANCEVALUE:
			return getHas_relevancevalue();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cams2024Package.CONTEXT_FEATURE__OBSERVER:
			getObserver().clear();
			getObserver().addAll((Collection<? extends Rule>) newValue);
			return;
		case Cams2024Package.CONTEXT_FEATURE__NAME:
			setName((String) newValue);
			return;
		case Cams2024Package.CONTEXT_FEATURE__LATITUD:
			setLatitud((Double) newValue);
			return;
		case Cams2024Package.CONTEXT_FEATURE__LONGITUD:
			setLongitud((Double) newValue);
			return;
		case Cams2024Package.CONTEXT_FEATURE__HAS_ABSTRACTSENSOR:
			getHas_abstractsensor().clear();
			getHas_abstractsensor().addAll((Collection<? extends AbstractSensor>) newValue);
			return;
		case Cams2024Package.CONTEXT_FEATURE__HAS_RELEVANCEVALUE:
			getHas_relevancevalue().clear();
			getHas_relevancevalue().addAll((Collection<? extends RelevanceValue>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cams2024Package.CONTEXT_FEATURE__OBSERVER:
			getObserver().clear();
			return;
		case Cams2024Package.CONTEXT_FEATURE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Cams2024Package.CONTEXT_FEATURE__LATITUD:
			setLatitud(LATITUD_EDEFAULT);
			return;
		case Cams2024Package.CONTEXT_FEATURE__LONGITUD:
			setLongitud(LONGITUD_EDEFAULT);
			return;
		case Cams2024Package.CONTEXT_FEATURE__HAS_ABSTRACTSENSOR:
			getHas_abstractsensor().clear();
			return;
		case Cams2024Package.CONTEXT_FEATURE__HAS_RELEVANCEVALUE:
			getHas_relevancevalue().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cams2024Package.CONTEXT_FEATURE__OBSERVER:
			return observer != null && !observer.isEmpty();
		case Cams2024Package.CONTEXT_FEATURE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Cams2024Package.CONTEXT_FEATURE__LATITUD:
			return latitud != LATITUD_EDEFAULT;
		case Cams2024Package.CONTEXT_FEATURE__LONGITUD:
			return longitud != LONGITUD_EDEFAULT;
		case Cams2024Package.CONTEXT_FEATURE__HAS_ABSTRACTSENSOR:
			return has_abstractsensor != null && !has_abstractsensor.isEmpty();
		case Cams2024Package.CONTEXT_FEATURE__HAS_RELEVANCEVALUE:
			return has_relevancevalue != null && !has_relevancevalue.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", Latitud: ");
		result.append(latitud);
		result.append(", Longitud: ");
		result.append(longitud);
		result.append(')');
		return result.toString();
	}

} //ContextFeatureImpl
