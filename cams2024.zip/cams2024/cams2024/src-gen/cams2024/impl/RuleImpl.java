/**
 */
package cams2024.impl;

import cams2024.Cams2024Package;
import cams2024.ContextFeature;
import cams2024.Rule;
import cams2024.Service;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link cams2024.impl.RuleImpl#getExecutes <em>Executes</em>}</li>
 *   <li>{@link cams2024.impl.RuleImpl#getRule_description <em>Rule description</em>}</li>
 *   <li>{@link cams2024.impl.RuleImpl#getUpdate <em>Update</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RuleImpl extends MinimalEObjectImpl.Container implements Rule {
	/**
	 * The cached value of the '{@link #getExecutes() <em>Executes</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExecutes()
	 * @generated
	 * @ordered
	 */
	protected Service executes;

	/**
	 * The default value of the '{@link #getRule_description() <em>Rule description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRule_description()
	 * @generated
	 * @ordered
	 */
	protected static final String RULE_DESCRIPTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getRule_description() <em>Rule description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRule_description()
	 * @generated
	 * @ordered
	 */
	protected String rule_description = RULE_DESCRIPTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getUpdate() <em>Update</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUpdate()
	 * @generated
	 * @ordered
	 */
	protected EList<ContextFeature> update;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cams2024Package.Literals.RULE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Service getExecutes() {
		if (executes != null && executes.eIsProxy()) {
			InternalEObject oldExecutes = (InternalEObject) executes;
			executes = (Service) eResolveProxy(oldExecutes);
			if (executes != oldExecutes) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cams2024Package.RULE__EXECUTES,
							oldExecutes, executes));
			}
		}
		return executes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Service basicGetExecutes() {
		return executes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setExecutes(Service newExecutes) {
		Service oldExecutes = executes;
		executes = newExecutes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cams2024Package.RULE__EXECUTES, oldExecutes,
					executes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getRule_description() {
		return rule_description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRule_description(String newRule_description) {
		String oldRule_description = rule_description;
		rule_description = newRule_description;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cams2024Package.RULE__RULE_DESCRIPTION,
					oldRule_description, rule_description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<ContextFeature> getUpdate() {
		if (update == null) {
			update = new EObjectResolvingEList<ContextFeature>(ContextFeature.class, this,
					Cams2024Package.RULE__UPDATE);
		}
		return update;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cams2024Package.RULE__EXECUTES:
			if (resolve)
				return getExecutes();
			return basicGetExecutes();
		case Cams2024Package.RULE__RULE_DESCRIPTION:
			return getRule_description();
		case Cams2024Package.RULE__UPDATE:
			return getUpdate();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cams2024Package.RULE__EXECUTES:
			setExecutes((Service) newValue);
			return;
		case Cams2024Package.RULE__RULE_DESCRIPTION:
			setRule_description((String) newValue);
			return;
		case Cams2024Package.RULE__UPDATE:
			getUpdate().clear();
			getUpdate().addAll((Collection<? extends ContextFeature>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cams2024Package.RULE__EXECUTES:
			setExecutes((Service) null);
			return;
		case Cams2024Package.RULE__RULE_DESCRIPTION:
			setRule_description(RULE_DESCRIPTION_EDEFAULT);
			return;
		case Cams2024Package.RULE__UPDATE:
			getUpdate().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cams2024Package.RULE__EXECUTES:
			return executes != null;
		case Cams2024Package.RULE__RULE_DESCRIPTION:
			return RULE_DESCRIPTION_EDEFAULT == null ? rule_description != null
					: !RULE_DESCRIPTION_EDEFAULT.equals(rule_description);
		case Cams2024Package.RULE__UPDATE:
			return update != null && !update.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (rule_description: ");
		result.append(rule_description);
		result.append(')');
		return result.toString();
	}

} //RuleImpl
