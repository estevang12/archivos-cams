/**
 */
package cams2024.impl;

import cams2024.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Cams2024FactoryImpl extends EFactoryImpl implements Cams2024Factory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Cams2024Factory init() {
		try {
			Cams2024Factory theCams2024Factory = (Cams2024Factory) EPackage.Registry.INSTANCE
					.getEFactory(Cams2024Package.eNS_URI);
			if (theCams2024Factory != null) {
				return theCams2024Factory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Cams2024FactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cams2024FactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case Cams2024Package.METAMODEL:
			return createMetamodel();
		case Cams2024Package.AWARE_OBJECT:
			return createAwareObject();
		case Cams2024Package.CONTEXT_FEATURE:
			return createContextFeature();
		case Cams2024Package.ABSTRACT_SENSOR:
			return createAbstractSensor();
		case Cams2024Package.RELEVANCE_VALUE:
			return createRelevanceValue();
		case Cams2024Package.CATEGORY_VALUE:
			return createCategoryValue();
		case Cams2024Package.RULE:
			return createRule();
		case Cams2024Package.CONCRET_SENSOR:
			return createConcretSensor();
		case Cams2024Package.PRESITION_MARGIN_VALUE:
			return createPresitionMarginValue();
		case Cams2024Package.SERVICE:
			return createService();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case Cams2024Package.SERVICES_TYPE:
			return createServicesTypeFromString(eDataType, initialValue);
		case Cams2024Package.CATEG_VALUE:
			return createCateg_valueFromString(eDataType, initialValue);
		case Cams2024Package.REL_VALUE:
			return createRelValueFromString(eDataType, initialValue);
		case Cams2024Package.SENSOR_TYPE:
			return createSensorTypeFromString(eDataType, initialValue);
		case Cams2024Package.CONFIGURATION_TYPE:
			return createConfigurationTypeFromString(eDataType, initialValue);
		case Cams2024Package.EXECUTION_TYPE:
			return createExecutionTypeFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case Cams2024Package.SERVICES_TYPE:
			return convertServicesTypeToString(eDataType, instanceValue);
		case Cams2024Package.CATEG_VALUE:
			return convertCateg_valueToString(eDataType, instanceValue);
		case Cams2024Package.REL_VALUE:
			return convertRelValueToString(eDataType, instanceValue);
		case Cams2024Package.SENSOR_TYPE:
			return convertSensorTypeToString(eDataType, instanceValue);
		case Cams2024Package.CONFIGURATION_TYPE:
			return convertConfigurationTypeToString(eDataType, instanceValue);
		case Cams2024Package.EXECUTION_TYPE:
			return convertExecutionTypeToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Metamodel createMetamodel() {
		MetamodelImpl metamodel = new MetamodelImpl();
		return metamodel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AwareObject createAwareObject() {
		AwareObjectImpl awareObject = new AwareObjectImpl();
		return awareObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ContextFeature createContextFeature() {
		ContextFeatureImpl contextFeature = new ContextFeatureImpl();
		return contextFeature;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AbstractSensor createAbstractSensor() {
		AbstractSensorImpl abstractSensor = new AbstractSensorImpl();
		return abstractSensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RelevanceValue createRelevanceValue() {
		RelevanceValueImpl relevanceValue = new RelevanceValueImpl();
		return relevanceValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CategoryValue createCategoryValue() {
		CategoryValueImpl categoryValue = new CategoryValueImpl();
		return categoryValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Rule createRule() {
		RuleImpl rule = new RuleImpl();
		return rule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConcretSensor createConcretSensor() {
		ConcretSensorImpl concretSensor = new ConcretSensorImpl();
		return concretSensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PresitionMarginValue createPresitionMarginValue() {
		PresitionMarginValueImpl presitionMarginValue = new PresitionMarginValueImpl();
		return presitionMarginValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Service createService() {
		ServiceImpl service = new ServiceImpl();
		return service;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ServicesType createServicesTypeFromString(EDataType eDataType, String initialValue) {
		ServicesType result = ServicesType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertServicesTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Categ_value createCateg_valueFromString(EDataType eDataType, String initialValue) {
		Categ_value result = Categ_value.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCateg_valueToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RelValue createRelValueFromString(EDataType eDataType, String initialValue) {
		RelValue result = RelValue.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertRelValueToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SensorType createSensorTypeFromString(EDataType eDataType, String initialValue) {
		SensorType result = SensorType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertSensorTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConfigurationType createConfigurationTypeFromString(EDataType eDataType, String initialValue) {
		ConfigurationType result = ConfigurationType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertConfigurationTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExecutionType createExecutionTypeFromString(EDataType eDataType, String initialValue) {
		ExecutionType result = ExecutionType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertExecutionTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Cams2024Package getCams2024Package() {
		return (Cams2024Package) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static Cams2024Package getPackage() {
		return Cams2024Package.eINSTANCE;
	}

} //Cams2024FactoryImpl
