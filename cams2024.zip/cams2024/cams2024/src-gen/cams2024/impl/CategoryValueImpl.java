/**
 */
package cams2024.impl;

import cams2024.Cams2024Package;
import cams2024.Categ_value;
import cams2024.CategoryValue;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Category Value</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link cams2024.impl.CategoryValueImpl#getValue_of_categ <em>Value of categ</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CategoryValueImpl extends MinimalEObjectImpl.Container implements CategoryValue {
	/**
	 * The default value of the '{@link #getValue_of_categ() <em>Value of categ</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue_of_categ()
	 * @generated
	 * @ordered
	 */
	protected static final Categ_value VALUE_OF_CATEG_EDEFAULT = Categ_value.USER;

	/**
	 * The cached value of the '{@link #getValue_of_categ() <em>Value of categ</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue_of_categ()
	 * @generated
	 * @ordered
	 */
	protected Categ_value value_of_categ = VALUE_OF_CATEG_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CategoryValueImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cams2024Package.Literals.CATEGORY_VALUE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Categ_value getValue_of_categ() {
		return value_of_categ;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setValue_of_categ(Categ_value newValue_of_categ) {
		Categ_value oldValue_of_categ = value_of_categ;
		value_of_categ = newValue_of_categ == null ? VALUE_OF_CATEG_EDEFAULT : newValue_of_categ;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cams2024Package.CATEGORY_VALUE__VALUE_OF_CATEG,
					oldValue_of_categ, value_of_categ));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cams2024Package.CATEGORY_VALUE__VALUE_OF_CATEG:
			return getValue_of_categ();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cams2024Package.CATEGORY_VALUE__VALUE_OF_CATEG:
			setValue_of_categ((Categ_value) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cams2024Package.CATEGORY_VALUE__VALUE_OF_CATEG:
			setValue_of_categ(VALUE_OF_CATEG_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cams2024Package.CATEGORY_VALUE__VALUE_OF_CATEG:
			return value_of_categ != VALUE_OF_CATEG_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (value_of_categ: ");
		result.append(value_of_categ);
		result.append(')');
		return result.toString();
	}

} //CategoryValueImpl
