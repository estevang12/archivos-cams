/**
 */
package cams2024.impl;

import cams2024.AbstractSensor;
import cams2024.Cams2024Package;
import cams2024.ConcretSensor;
import cams2024.SensorType;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Abstract Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link cams2024.impl.AbstractSensorImpl#getSensorType <em>Sensor Type</em>}</li>
 *   <li>{@link cams2024.impl.AbstractSensorImpl#getCorresponds_to_concretsensor <em>Corresponds to concretsensor</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AbstractSensorImpl extends MinimalEObjectImpl.Container implements AbstractSensor {
	/**
	 * The default value of the '{@link #getSensorType() <em>Sensor Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSensorType()
	 * @generated
	 * @ordered
	 */
	protected static final SensorType SENSOR_TYPE_EDEFAULT = SensorType.NOT_DEFINED;

	/**
	 * The cached value of the '{@link #getSensorType() <em>Sensor Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSensorType()
	 * @generated
	 * @ordered
	 */
	protected SensorType sensorType = SENSOR_TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCorresponds_to_concretsensor() <em>Corresponds to concretsensor</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCorresponds_to_concretsensor()
	 * @generated
	 * @ordered
	 */
	protected EList<ConcretSensor> corresponds_to_concretsensor;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AbstractSensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cams2024Package.Literals.ABSTRACT_SENSOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SensorType getSensorType() {
		return sensorType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSensorType(SensorType newSensorType) {
		SensorType oldSensorType = sensorType;
		sensorType = newSensorType == null ? SENSOR_TYPE_EDEFAULT : newSensorType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cams2024Package.ABSTRACT_SENSOR__SENSOR_TYPE,
					oldSensorType, sensorType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<ConcretSensor> getCorresponds_to_concretsensor() {
		if (corresponds_to_concretsensor == null) {
			corresponds_to_concretsensor = new EObjectContainmentEList<ConcretSensor>(ConcretSensor.class, this,
					Cams2024Package.ABSTRACT_SENSOR__CORRESPONDS_TO_CONCRETSENSOR);
		}
		return corresponds_to_concretsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cams2024Package.ABSTRACT_SENSOR__CORRESPONDS_TO_CONCRETSENSOR:
			return ((InternalEList<?>) getCorresponds_to_concretsensor()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cams2024Package.ABSTRACT_SENSOR__SENSOR_TYPE:
			return getSensorType();
		case Cams2024Package.ABSTRACT_SENSOR__CORRESPONDS_TO_CONCRETSENSOR:
			return getCorresponds_to_concretsensor();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cams2024Package.ABSTRACT_SENSOR__SENSOR_TYPE:
			setSensorType((SensorType) newValue);
			return;
		case Cams2024Package.ABSTRACT_SENSOR__CORRESPONDS_TO_CONCRETSENSOR:
			getCorresponds_to_concretsensor().clear();
			getCorresponds_to_concretsensor().addAll((Collection<? extends ConcretSensor>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cams2024Package.ABSTRACT_SENSOR__SENSOR_TYPE:
			setSensorType(SENSOR_TYPE_EDEFAULT);
			return;
		case Cams2024Package.ABSTRACT_SENSOR__CORRESPONDS_TO_CONCRETSENSOR:
			getCorresponds_to_concretsensor().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cams2024Package.ABSTRACT_SENSOR__SENSOR_TYPE:
			return sensorType != SENSOR_TYPE_EDEFAULT;
		case Cams2024Package.ABSTRACT_SENSOR__CORRESPONDS_TO_CONCRETSENSOR:
			return corresponds_to_concretsensor != null && !corresponds_to_concretsensor.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (sensorType: ");
		result.append(sensorType);
		result.append(')');
		return result.toString();
	}

} //AbstractSensorImpl
