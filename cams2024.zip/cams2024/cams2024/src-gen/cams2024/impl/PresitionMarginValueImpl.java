/**
 */
package cams2024.impl;

import cams2024.Cams2024Package;
import cams2024.PresitionMarginValue;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Presition Margin Value</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link cams2024.impl.PresitionMarginValueImpl#getV1 <em>V1</em>}</li>
 *   <li>{@link cams2024.impl.PresitionMarginValueImpl#getVF <em>VF</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PresitionMarginValueImpl extends MinimalEObjectImpl.Container implements PresitionMarginValue {
	/**
	 * The default value of the '{@link #getV1() <em>V1</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getV1()
	 * @generated
	 * @ordered
	 */
	protected static final double V1_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getV1() <em>V1</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getV1()
	 * @generated
	 * @ordered
	 */
	protected double v1 = V1_EDEFAULT;

	/**
	 * The default value of the '{@link #getVF() <em>VF</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVF()
	 * @generated
	 * @ordered
	 */
	protected static final double VF_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getVF() <em>VF</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVF()
	 * @generated
	 * @ordered
	 */
	protected double vf = VF_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PresitionMarginValueImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cams2024Package.Literals.PRESITION_MARGIN_VALUE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getV1() {
		return v1;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setV1(double newV1) {
		double oldV1 = v1;
		v1 = newV1;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cams2024Package.PRESITION_MARGIN_VALUE__V1, oldV1,
					v1));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getVF() {
		return vf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVF(double newVF) {
		double oldVF = vf;
		vf = newVF;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cams2024Package.PRESITION_MARGIN_VALUE__VF, oldVF,
					vf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cams2024Package.PRESITION_MARGIN_VALUE__V1:
			return getV1();
		case Cams2024Package.PRESITION_MARGIN_VALUE__VF:
			return getVF();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cams2024Package.PRESITION_MARGIN_VALUE__V1:
			setV1((Double) newValue);
			return;
		case Cams2024Package.PRESITION_MARGIN_VALUE__VF:
			setVF((Double) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cams2024Package.PRESITION_MARGIN_VALUE__V1:
			setV1(V1_EDEFAULT);
			return;
		case Cams2024Package.PRESITION_MARGIN_VALUE__VF:
			setVF(VF_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cams2024Package.PRESITION_MARGIN_VALUE__V1:
			return v1 != V1_EDEFAULT;
		case Cams2024Package.PRESITION_MARGIN_VALUE__VF:
			return vf != VF_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (V1: ");
		result.append(v1);
		result.append(", VF: ");
		result.append(vf);
		result.append(')');
		return result.toString();
	}

} //PresitionMarginValueImpl
