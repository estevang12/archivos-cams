/**
 */
package cams2024.impl;

import cams2024.AwareObject;
import cams2024.Cams2024Package;
import cams2024.CategoryValue;
import cams2024.ContextFeature;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Aware Object</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link cams2024.impl.AwareObjectImpl#getName <em>Name</em>}</li>
 *   <li>{@link cams2024.impl.AwareObjectImpl#getHas_contextfeature <em>Has contextfeature</em>}</li>
 *   <li>{@link cams2024.impl.AwareObjectImpl#getBelong_categoryvalue <em>Belong categoryvalue</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AwareObjectImpl extends MinimalEObjectImpl.Container implements AwareObject {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getHas_contextfeature() <em>Has contextfeature</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHas_contextfeature()
	 * @generated
	 * @ordered
	 */
	protected EList<ContextFeature> has_contextfeature;

	/**
	 * The cached value of the '{@link #getBelong_categoryvalue() <em>Belong categoryvalue</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBelong_categoryvalue()
	 * @generated
	 * @ordered
	 */
	protected EList<CategoryValue> belong_categoryvalue;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AwareObjectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cams2024Package.Literals.AWARE_OBJECT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cams2024Package.AWARE_OBJECT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<ContextFeature> getHas_contextfeature() {
		if (has_contextfeature == null) {
			has_contextfeature = new EObjectContainmentEList<ContextFeature>(ContextFeature.class, this,
					Cams2024Package.AWARE_OBJECT__HAS_CONTEXTFEATURE);
		}
		return has_contextfeature;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<CategoryValue> getBelong_categoryvalue() {
		if (belong_categoryvalue == null) {
			belong_categoryvalue = new EObjectContainmentEList<CategoryValue>(CategoryValue.class, this,
					Cams2024Package.AWARE_OBJECT__BELONG_CATEGORYVALUE);
		}
		return belong_categoryvalue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cams2024Package.AWARE_OBJECT__HAS_CONTEXTFEATURE:
			return ((InternalEList<?>) getHas_contextfeature()).basicRemove(otherEnd, msgs);
		case Cams2024Package.AWARE_OBJECT__BELONG_CATEGORYVALUE:
			return ((InternalEList<?>) getBelong_categoryvalue()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cams2024Package.AWARE_OBJECT__NAME:
			return getName();
		case Cams2024Package.AWARE_OBJECT__HAS_CONTEXTFEATURE:
			return getHas_contextfeature();
		case Cams2024Package.AWARE_OBJECT__BELONG_CATEGORYVALUE:
			return getBelong_categoryvalue();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cams2024Package.AWARE_OBJECT__NAME:
			setName((String) newValue);
			return;
		case Cams2024Package.AWARE_OBJECT__HAS_CONTEXTFEATURE:
			getHas_contextfeature().clear();
			getHas_contextfeature().addAll((Collection<? extends ContextFeature>) newValue);
			return;
		case Cams2024Package.AWARE_OBJECT__BELONG_CATEGORYVALUE:
			getBelong_categoryvalue().clear();
			getBelong_categoryvalue().addAll((Collection<? extends CategoryValue>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cams2024Package.AWARE_OBJECT__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Cams2024Package.AWARE_OBJECT__HAS_CONTEXTFEATURE:
			getHas_contextfeature().clear();
			return;
		case Cams2024Package.AWARE_OBJECT__BELONG_CATEGORYVALUE:
			getBelong_categoryvalue().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cams2024Package.AWARE_OBJECT__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Cams2024Package.AWARE_OBJECT__HAS_CONTEXTFEATURE:
			return has_contextfeature != null && !has_contextfeature.isEmpty();
		case Cams2024Package.AWARE_OBJECT__BELONG_CATEGORYVALUE:
			return belong_categoryvalue != null && !belong_categoryvalue.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //AwareObjectImpl
