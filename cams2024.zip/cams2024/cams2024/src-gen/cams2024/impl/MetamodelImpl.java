/**
 */
package cams2024.impl;

import cams2024.AbstractSensor;
import cams2024.AwareObject;
import cams2024.Cams2024Package;
import cams2024.CategoryValue;
import cams2024.ConcretSensor;
import cams2024.ContextFeature;
import cams2024.Metamodel;
import cams2024.PresitionMarginValue;
import cams2024.RelevanceValue;
import cams2024.Rule;
import cams2024.Service;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Metamodel</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link cams2024.impl.MetamodelImpl#getAwareobject <em>Awareobject</em>}</li>
 *   <li>{@link cams2024.impl.MetamodelImpl#getContextfeature <em>Contextfeature</em>}</li>
 *   <li>{@link cams2024.impl.MetamodelImpl#getAbstractsensor <em>Abstractsensor</em>}</li>
 *   <li>{@link cams2024.impl.MetamodelImpl#getRelevancevalue <em>Relevancevalue</em>}</li>
 *   <li>{@link cams2024.impl.MetamodelImpl#getCategoryvalue <em>Categoryvalue</em>}</li>
 *   <li>{@link cams2024.impl.MetamodelImpl#getRule <em>Rule</em>}</li>
 *   <li>{@link cams2024.impl.MetamodelImpl#getConcretsensor <em>Concretsensor</em>}</li>
 *   <li>{@link cams2024.impl.MetamodelImpl#getPresitionmarginvalue <em>Presitionmarginvalue</em>}</li>
 *   <li>{@link cams2024.impl.MetamodelImpl#getService <em>Service</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MetamodelImpl extends MinimalEObjectImpl.Container implements Metamodel {
	/**
	 * The cached value of the '{@link #getAwareobject() <em>Awareobject</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAwareobject()
	 * @generated
	 * @ordered
	 */
	protected EList<AwareObject> awareobject;

	/**
	 * The cached value of the '{@link #getContextfeature() <em>Contextfeature</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContextfeature()
	 * @generated
	 * @ordered
	 */
	protected EList<ContextFeature> contextfeature;

	/**
	 * The cached value of the '{@link #getAbstractsensor() <em>Abstractsensor</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAbstractsensor()
	 * @generated
	 * @ordered
	 */
	protected EList<AbstractSensor> abstractsensor;

	/**
	 * The cached value of the '{@link #getRelevancevalue() <em>Relevancevalue</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRelevancevalue()
	 * @generated
	 * @ordered
	 */
	protected EList<RelevanceValue> relevancevalue;

	/**
	 * The cached value of the '{@link #getCategoryvalue() <em>Categoryvalue</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCategoryvalue()
	 * @generated
	 * @ordered
	 */
	protected EList<CategoryValue> categoryvalue;

	/**
	 * The cached value of the '{@link #getRule() <em>Rule</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRule()
	 * @generated
	 * @ordered
	 */
	protected EList<Rule> rule;

	/**
	 * The cached value of the '{@link #getConcretsensor() <em>Concretsensor</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConcretsensor()
	 * @generated
	 * @ordered
	 */
	protected EList<ConcretSensor> concretsensor;

	/**
	 * The cached value of the '{@link #getPresitionmarginvalue() <em>Presitionmarginvalue</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPresitionmarginvalue()
	 * @generated
	 * @ordered
	 */
	protected EList<PresitionMarginValue> presitionmarginvalue;

	/**
	 * The cached value of the '{@link #getService() <em>Service</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getService()
	 * @generated
	 * @ordered
	 */
	protected EList<Service> service;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MetamodelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cams2024Package.Literals.METAMODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<AwareObject> getAwareobject() {
		if (awareobject == null) {
			awareobject = new EObjectContainmentEList<AwareObject>(AwareObject.class, this,
					Cams2024Package.METAMODEL__AWAREOBJECT);
		}
		return awareobject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<ContextFeature> getContextfeature() {
		if (contextfeature == null) {
			contextfeature = new EObjectContainmentEList<ContextFeature>(ContextFeature.class, this,
					Cams2024Package.METAMODEL__CONTEXTFEATURE);
		}
		return contextfeature;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<AbstractSensor> getAbstractsensor() {
		if (abstractsensor == null) {
			abstractsensor = new EObjectContainmentEList<AbstractSensor>(AbstractSensor.class, this,
					Cams2024Package.METAMODEL__ABSTRACTSENSOR);
		}
		return abstractsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<RelevanceValue> getRelevancevalue() {
		if (relevancevalue == null) {
			relevancevalue = new EObjectContainmentEList<RelevanceValue>(RelevanceValue.class, this,
					Cams2024Package.METAMODEL__RELEVANCEVALUE);
		}
		return relevancevalue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<CategoryValue> getCategoryvalue() {
		if (categoryvalue == null) {
			categoryvalue = new EObjectContainmentEList<CategoryValue>(CategoryValue.class, this,
					Cams2024Package.METAMODEL__CATEGORYVALUE);
		}
		return categoryvalue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Rule> getRule() {
		if (rule == null) {
			rule = new EObjectContainmentEList<Rule>(Rule.class, this, Cams2024Package.METAMODEL__RULE);
		}
		return rule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<ConcretSensor> getConcretsensor() {
		if (concretsensor == null) {
			concretsensor = new EObjectContainmentEList<ConcretSensor>(ConcretSensor.class, this,
					Cams2024Package.METAMODEL__CONCRETSENSOR);
		}
		return concretsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PresitionMarginValue> getPresitionmarginvalue() {
		if (presitionmarginvalue == null) {
			presitionmarginvalue = new EObjectContainmentEList<PresitionMarginValue>(PresitionMarginValue.class, this,
					Cams2024Package.METAMODEL__PRESITIONMARGINVALUE);
		}
		return presitionmarginvalue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Service> getService() {
		if (service == null) {
			service = new EObjectContainmentEList<Service>(Service.class, this, Cams2024Package.METAMODEL__SERVICE);
		}
		return service;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cams2024Package.METAMODEL__AWAREOBJECT:
			return ((InternalEList<?>) getAwareobject()).basicRemove(otherEnd, msgs);
		case Cams2024Package.METAMODEL__CONTEXTFEATURE:
			return ((InternalEList<?>) getContextfeature()).basicRemove(otherEnd, msgs);
		case Cams2024Package.METAMODEL__ABSTRACTSENSOR:
			return ((InternalEList<?>) getAbstractsensor()).basicRemove(otherEnd, msgs);
		case Cams2024Package.METAMODEL__RELEVANCEVALUE:
			return ((InternalEList<?>) getRelevancevalue()).basicRemove(otherEnd, msgs);
		case Cams2024Package.METAMODEL__CATEGORYVALUE:
			return ((InternalEList<?>) getCategoryvalue()).basicRemove(otherEnd, msgs);
		case Cams2024Package.METAMODEL__RULE:
			return ((InternalEList<?>) getRule()).basicRemove(otherEnd, msgs);
		case Cams2024Package.METAMODEL__CONCRETSENSOR:
			return ((InternalEList<?>) getConcretsensor()).basicRemove(otherEnd, msgs);
		case Cams2024Package.METAMODEL__PRESITIONMARGINVALUE:
			return ((InternalEList<?>) getPresitionmarginvalue()).basicRemove(otherEnd, msgs);
		case Cams2024Package.METAMODEL__SERVICE:
			return ((InternalEList<?>) getService()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cams2024Package.METAMODEL__AWAREOBJECT:
			return getAwareobject();
		case Cams2024Package.METAMODEL__CONTEXTFEATURE:
			return getContextfeature();
		case Cams2024Package.METAMODEL__ABSTRACTSENSOR:
			return getAbstractsensor();
		case Cams2024Package.METAMODEL__RELEVANCEVALUE:
			return getRelevancevalue();
		case Cams2024Package.METAMODEL__CATEGORYVALUE:
			return getCategoryvalue();
		case Cams2024Package.METAMODEL__RULE:
			return getRule();
		case Cams2024Package.METAMODEL__CONCRETSENSOR:
			return getConcretsensor();
		case Cams2024Package.METAMODEL__PRESITIONMARGINVALUE:
			return getPresitionmarginvalue();
		case Cams2024Package.METAMODEL__SERVICE:
			return getService();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cams2024Package.METAMODEL__AWAREOBJECT:
			getAwareobject().clear();
			getAwareobject().addAll((Collection<? extends AwareObject>) newValue);
			return;
		case Cams2024Package.METAMODEL__CONTEXTFEATURE:
			getContextfeature().clear();
			getContextfeature().addAll((Collection<? extends ContextFeature>) newValue);
			return;
		case Cams2024Package.METAMODEL__ABSTRACTSENSOR:
			getAbstractsensor().clear();
			getAbstractsensor().addAll((Collection<? extends AbstractSensor>) newValue);
			return;
		case Cams2024Package.METAMODEL__RELEVANCEVALUE:
			getRelevancevalue().clear();
			getRelevancevalue().addAll((Collection<? extends RelevanceValue>) newValue);
			return;
		case Cams2024Package.METAMODEL__CATEGORYVALUE:
			getCategoryvalue().clear();
			getCategoryvalue().addAll((Collection<? extends CategoryValue>) newValue);
			return;
		case Cams2024Package.METAMODEL__RULE:
			getRule().clear();
			getRule().addAll((Collection<? extends Rule>) newValue);
			return;
		case Cams2024Package.METAMODEL__CONCRETSENSOR:
			getConcretsensor().clear();
			getConcretsensor().addAll((Collection<? extends ConcretSensor>) newValue);
			return;
		case Cams2024Package.METAMODEL__PRESITIONMARGINVALUE:
			getPresitionmarginvalue().clear();
			getPresitionmarginvalue().addAll((Collection<? extends PresitionMarginValue>) newValue);
			return;
		case Cams2024Package.METAMODEL__SERVICE:
			getService().clear();
			getService().addAll((Collection<? extends Service>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cams2024Package.METAMODEL__AWAREOBJECT:
			getAwareobject().clear();
			return;
		case Cams2024Package.METAMODEL__CONTEXTFEATURE:
			getContextfeature().clear();
			return;
		case Cams2024Package.METAMODEL__ABSTRACTSENSOR:
			getAbstractsensor().clear();
			return;
		case Cams2024Package.METAMODEL__RELEVANCEVALUE:
			getRelevancevalue().clear();
			return;
		case Cams2024Package.METAMODEL__CATEGORYVALUE:
			getCategoryvalue().clear();
			return;
		case Cams2024Package.METAMODEL__RULE:
			getRule().clear();
			return;
		case Cams2024Package.METAMODEL__CONCRETSENSOR:
			getConcretsensor().clear();
			return;
		case Cams2024Package.METAMODEL__PRESITIONMARGINVALUE:
			getPresitionmarginvalue().clear();
			return;
		case Cams2024Package.METAMODEL__SERVICE:
			getService().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cams2024Package.METAMODEL__AWAREOBJECT:
			return awareobject != null && !awareobject.isEmpty();
		case Cams2024Package.METAMODEL__CONTEXTFEATURE:
			return contextfeature != null && !contextfeature.isEmpty();
		case Cams2024Package.METAMODEL__ABSTRACTSENSOR:
			return abstractsensor != null && !abstractsensor.isEmpty();
		case Cams2024Package.METAMODEL__RELEVANCEVALUE:
			return relevancevalue != null && !relevancevalue.isEmpty();
		case Cams2024Package.METAMODEL__CATEGORYVALUE:
			return categoryvalue != null && !categoryvalue.isEmpty();
		case Cams2024Package.METAMODEL__RULE:
			return rule != null && !rule.isEmpty();
		case Cams2024Package.METAMODEL__CONCRETSENSOR:
			return concretsensor != null && !concretsensor.isEmpty();
		case Cams2024Package.METAMODEL__PRESITIONMARGINVALUE:
			return presitionmarginvalue != null && !presitionmarginvalue.isEmpty();
		case Cams2024Package.METAMODEL__SERVICE:
			return service != null && !service.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //MetamodelImpl
