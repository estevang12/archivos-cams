/**
 */
package cams2024.impl;

import cams2024.AbstractSensor;
import cams2024.AwareObject;
import cams2024.Cams2024Factory;
import cams2024.Cams2024Package;
import cams2024.Categ_value;
import cams2024.CategoryValue;
import cams2024.ConcretSensor;
import cams2024.ConfigurationType;
import cams2024.ContextFeature;
import cams2024.ExecutionType;
import cams2024.Metamodel;
import cams2024.PresitionMarginValue;
import cams2024.RelValue;
import cams2024.RelevanceValue;
import cams2024.Rule;
import cams2024.SensorType;
import cams2024.Service;
import cams2024.ServicesType;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Cams2024PackageImpl extends EPackageImpl implements Cams2024Package {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass metamodelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass awareObjectEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass contextFeatureEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractSensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass relevanceValueEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass categoryValueEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ruleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass concretSensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass presitionMarginValueEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass serviceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum servicesTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum categ_valueEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum relValueEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum sensorTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum configurationTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum executionTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see cams2024.Cams2024Package#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private Cams2024PackageImpl() {
		super(eNS_URI, Cams2024Factory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link Cams2024Package#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static Cams2024Package init() {
		if (isInited)
			return (Cams2024Package) EPackage.Registry.INSTANCE.getEPackage(Cams2024Package.eNS_URI);

		// Obtain or create and register package
		Object registeredCams2024Package = EPackage.Registry.INSTANCE.get(eNS_URI);
		Cams2024PackageImpl theCams2024Package = registeredCams2024Package instanceof Cams2024PackageImpl
				? (Cams2024PackageImpl) registeredCams2024Package
				: new Cams2024PackageImpl();

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Create package meta-data objects
		theCams2024Package.createPackageContents();

		// Initialize created meta-data
		theCams2024Package.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theCams2024Package.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Cams2024Package.eNS_URI, theCams2024Package);
		return theCams2024Package;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMetamodel() {
		return metamodelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMetamodel_Awareobject() {
		return (EReference) metamodelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMetamodel_Contextfeature() {
		return (EReference) metamodelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMetamodel_Abstractsensor() {
		return (EReference) metamodelEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMetamodel_Relevancevalue() {
		return (EReference) metamodelEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMetamodel_Categoryvalue() {
		return (EReference) metamodelEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMetamodel_Rule() {
		return (EReference) metamodelEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMetamodel_Concretsensor() {
		return (EReference) metamodelEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMetamodel_Presitionmarginvalue() {
		return (EReference) metamodelEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMetamodel_Service() {
		return (EReference) metamodelEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAwareObject() {
		return awareObjectEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getAwareObject_Name() {
		return (EAttribute) awareObjectEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAwareObject_Has_contextfeature() {
		return (EReference) awareObjectEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAwareObject_Belong_categoryvalue() {
		return (EReference) awareObjectEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getContextFeature() {
		return contextFeatureEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getContextFeature_Observer() {
		return (EReference) contextFeatureEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getContextFeature_Name() {
		return (EAttribute) contextFeatureEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getContextFeature_Latitud() {
		return (EAttribute) contextFeatureEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getContextFeature_Longitud() {
		return (EAttribute) contextFeatureEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getContextFeature_Has_abstractsensor() {
		return (EReference) contextFeatureEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getContextFeature_Has_relevancevalue() {
		return (EReference) contextFeatureEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAbstractSensor() {
		return abstractSensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getAbstractSensor_SensorType() {
		return (EAttribute) abstractSensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAbstractSensor_Corresponds_to_concretsensor() {
		return (EReference) abstractSensorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRelevanceValue() {
		return relevanceValueEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getRelevanceValue_Value_or_range() {
		return (EAttribute) relevanceValueEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCategoryValue() {
		return categoryValueEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getCategoryValue_Value_of_categ() {
		return (EAttribute) categoryValueEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRule() {
		return ruleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getRule_Executes() {
		return (EReference) ruleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getRule_Rule_description() {
		return (EAttribute) ruleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getRule_Update() {
		return (EReference) ruleEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getConcretSensor() {
		return concretSensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConcretSensor_Presitionmarginvalue() {
		return (EReference) concretSensorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getConcretSensor_Value_of_configuratio_type() {
		return (EAttribute) concretSensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getConcretSensor_ExecutionType() {
		return (EAttribute) concretSensorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPresitionMarginValue() {
		return presitionMarginValueEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPresitionMarginValue_V1() {
		return (EAttribute) presitionMarginValueEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPresitionMarginValue_VF() {
		return (EAttribute) presitionMarginValueEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getService() {
		return serviceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getService_Name() {
		return (EAttribute) serviceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getService_Type() {
		return (EAttribute) serviceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getServicesType() {
		return servicesTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getCateg_value() {
		return categ_valueEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getRelValue() {
		return relValueEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getSensorType() {
		return sensorTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getConfigurationType() {
		return configurationTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getExecutionType() {
		return executionTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Cams2024Factory getCams2024Factory() {
		return (Cams2024Factory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		metamodelEClass = createEClass(METAMODEL);
		createEReference(metamodelEClass, METAMODEL__AWAREOBJECT);
		createEReference(metamodelEClass, METAMODEL__CONTEXTFEATURE);
		createEReference(metamodelEClass, METAMODEL__ABSTRACTSENSOR);
		createEReference(metamodelEClass, METAMODEL__RELEVANCEVALUE);
		createEReference(metamodelEClass, METAMODEL__CATEGORYVALUE);
		createEReference(metamodelEClass, METAMODEL__RULE);
		createEReference(metamodelEClass, METAMODEL__CONCRETSENSOR);
		createEReference(metamodelEClass, METAMODEL__PRESITIONMARGINVALUE);
		createEReference(metamodelEClass, METAMODEL__SERVICE);

		awareObjectEClass = createEClass(AWARE_OBJECT);
		createEAttribute(awareObjectEClass, AWARE_OBJECT__NAME);
		createEReference(awareObjectEClass, AWARE_OBJECT__HAS_CONTEXTFEATURE);
		createEReference(awareObjectEClass, AWARE_OBJECT__BELONG_CATEGORYVALUE);

		contextFeatureEClass = createEClass(CONTEXT_FEATURE);
		createEReference(contextFeatureEClass, CONTEXT_FEATURE__OBSERVER);
		createEAttribute(contextFeatureEClass, CONTEXT_FEATURE__NAME);
		createEAttribute(contextFeatureEClass, CONTEXT_FEATURE__LATITUD);
		createEAttribute(contextFeatureEClass, CONTEXT_FEATURE__LONGITUD);
		createEReference(contextFeatureEClass, CONTEXT_FEATURE__HAS_ABSTRACTSENSOR);
		createEReference(contextFeatureEClass, CONTEXT_FEATURE__HAS_RELEVANCEVALUE);

		abstractSensorEClass = createEClass(ABSTRACT_SENSOR);
		createEAttribute(abstractSensorEClass, ABSTRACT_SENSOR__SENSOR_TYPE);
		createEReference(abstractSensorEClass, ABSTRACT_SENSOR__CORRESPONDS_TO_CONCRETSENSOR);

		relevanceValueEClass = createEClass(RELEVANCE_VALUE);
		createEAttribute(relevanceValueEClass, RELEVANCE_VALUE__VALUE_OR_RANGE);

		categoryValueEClass = createEClass(CATEGORY_VALUE);
		createEAttribute(categoryValueEClass, CATEGORY_VALUE__VALUE_OF_CATEG);

		ruleEClass = createEClass(RULE);
		createEReference(ruleEClass, RULE__EXECUTES);
		createEAttribute(ruleEClass, RULE__RULE_DESCRIPTION);
		createEReference(ruleEClass, RULE__UPDATE);

		concretSensorEClass = createEClass(CONCRET_SENSOR);
		createEAttribute(concretSensorEClass, CONCRET_SENSOR__VALUE_OF_CONFIGURATIO_TYPE);
		createEAttribute(concretSensorEClass, CONCRET_SENSOR__EXECUTION_TYPE);
		createEReference(concretSensorEClass, CONCRET_SENSOR__PRESITIONMARGINVALUE);

		presitionMarginValueEClass = createEClass(PRESITION_MARGIN_VALUE);
		createEAttribute(presitionMarginValueEClass, PRESITION_MARGIN_VALUE__V1);
		createEAttribute(presitionMarginValueEClass, PRESITION_MARGIN_VALUE__VF);

		serviceEClass = createEClass(SERVICE);
		createEAttribute(serviceEClass, SERVICE__NAME);
		createEAttribute(serviceEClass, SERVICE__TYPE);

		// Create enums
		servicesTypeEEnum = createEEnum(SERVICES_TYPE);
		categ_valueEEnum = createEEnum(CATEG_VALUE);
		relValueEEnum = createEEnum(REL_VALUE);
		sensorTypeEEnum = createEEnum(SENSOR_TYPE);
		configurationTypeEEnum = createEEnum(CONFIGURATION_TYPE);
		executionTypeEEnum = createEEnum(EXECUTION_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		XMLTypePackage theXMLTypePackage = (XMLTypePackage) EPackage.Registry.INSTANCE
				.getEPackage(XMLTypePackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(metamodelEClass, Metamodel.class, "Metamodel", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMetamodel_Awareobject(), this.getAwareObject(), null, "awareobject", null, 0, -1,
				Metamodel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMetamodel_Contextfeature(), this.getContextFeature(), null, "contextfeature", null, 0, -1,
				Metamodel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMetamodel_Abstractsensor(), this.getAbstractSensor(), null, "abstractsensor", null, 0, -1,
				Metamodel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMetamodel_Relevancevalue(), this.getRelevanceValue(), null, "relevancevalue", null, 0, -1,
				Metamodel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMetamodel_Categoryvalue(), this.getCategoryValue(), null, "categoryvalue", null, 0, -1,
				Metamodel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMetamodel_Rule(), this.getRule(), null, "rule", null, 0, -1, Metamodel.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getMetamodel_Concretsensor(), this.getConcretSensor(), null, "concretsensor", null, 0, -1,
				Metamodel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMetamodel_Presitionmarginvalue(), this.getPresitionMarginValue(), null,
				"presitionmarginvalue", null, 0, -1, Metamodel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMetamodel_Service(), this.getService(), null, "service", null, 0, -1, Metamodel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(awareObjectEClass, AwareObject.class, "AwareObject", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAwareObject_Name(), ecorePackage.getEString(), "name", null, 0, 1, AwareObject.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAwareObject_Has_contextfeature(), this.getContextFeature(), null, "has_contextfeature", null,
				0, -1, AwareObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAwareObject_Belong_categoryvalue(), this.getCategoryValue(), null, "belong_categoryvalue",
				null, 0, -1, AwareObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(contextFeatureEClass, ContextFeature.class, "ContextFeature", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getContextFeature_Observer(), this.getRule(), null, "observer", null, 1, -1,
				ContextFeature.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getContextFeature_Name(), ecorePackage.getEString(), "name", null, 0, 1, ContextFeature.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getContextFeature_Latitud(), ecorePackage.getEDouble(), "Latitud", "0.0", 0, 1,
				ContextFeature.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getContextFeature_Longitud(), theXMLTypePackage.getDouble(), "Longitud", null, 0, 1,
				ContextFeature.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getContextFeature_Has_abstractsensor(), this.getAbstractSensor(), null, "has_abstractsensor",
				null, 0, -1, ContextFeature.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getContextFeature_Has_relevancevalue(), this.getRelevanceValue(), null, "Has_relevancevalue",
				null, 0, -1, ContextFeature.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(abstractSensorEClass, AbstractSensor.class, "AbstractSensor", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAbstractSensor_SensorType(), this.getSensorType(), "sensorType", null, 0, 1,
				AbstractSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractSensor_Corresponds_to_concretsensor(), this.getConcretSensor(), null,
				"Corresponds_to_concretsensor", null, 0, -1, AbstractSensor.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(relevanceValueEClass, RelevanceValue.class, "RelevanceValue", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRelevanceValue_Value_or_range(), this.getRelValue(), "value_or_range", null, 0, 1,
				RelevanceValue.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(categoryValueEClass, CategoryValue.class, "CategoryValue", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCategoryValue_Value_of_categ(), this.getCateg_value(), "value_of_categ", "User", 0, 1,
				CategoryValue.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(ruleEClass, Rule.class, "Rule", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRule_Executes(), this.getService(), null, "executes", null, 0, 1, Rule.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEAttribute(getRule_Rule_description(), ecorePackage.getEString(), "rule_description", null, 0, 1,
				Rule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getRule_Update(), this.getContextFeature(), null, "update", null, 0, -1, Rule.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(concretSensorEClass, ConcretSensor.class, "ConcretSensor", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getConcretSensor_Value_of_configuratio_type(), this.getConfigurationType(),
				"value_of_configuratio_type", null, 0, 1, ConcretSensor.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConcretSensor_ExecutionType(), this.getExecutionType(), "ExecutionType", null, 0, 1,
				ConcretSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getConcretSensor_Presitionmarginvalue(), this.getPresitionMarginValue(), null,
				"presitionmarginvalue", null, 0, -1, ConcretSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(presitionMarginValueEClass, PresitionMarginValue.class, "PresitionMarginValue", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPresitionMarginValue_V1(), theXMLTypePackage.getDouble(), "V1", "0.0", 0, 1,
				PresitionMarginValue.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPresitionMarginValue_VF(), theXMLTypePackage.getDouble(), "VF", "0.0", 0, 1,
				PresitionMarginValue.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(serviceEClass, Service.class, "Service", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getService_Name(), ecorePackage.getEString(), "name", null, 0, 1, Service.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getService_Type(), this.getServicesType(), "type", null, 0, 1, Service.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(servicesTypeEEnum, ServicesType.class, "ServicesType");
		addEEnumLiteral(servicesTypeEEnum, ServicesType.NOT_DEFINED);
		addEEnumLiteral(servicesTypeEEnum, ServicesType.SERVICE1);
		addEEnumLiteral(servicesTypeEEnum, ServicesType.SERVICE2);
		addEEnumLiteral(servicesTypeEEnum, ServicesType.AZURE_MAPS);

		initEEnum(categ_valueEEnum, Categ_value.class, "Categ_value");
		addEEnumLiteral(categ_valueEEnum, Categ_value.USER);
		addEEnumLiteral(categ_valueEEnum, Categ_value.MOBILE_OBJECT);
		addEEnumLiteral(categ_valueEEnum, Categ_value.ENVIRONMENT);

		initEEnum(relValueEEnum, RelValue.class, "RelValue");
		addEEnumLiteral(relValueEEnum, RelValue.LOW);
		addEEnumLiteral(relValueEEnum, RelValue.MEDIUM);
		addEEnumLiteral(relValueEEnum, RelValue.HIGH);

		initEEnum(sensorTypeEEnum, SensorType.class, "SensorType");
		addEEnumLiteral(sensorTypeEEnum, SensorType.NOT_DEFINED);
		addEEnumLiteral(sensorTypeEEnum, SensorType.GPS);
		addEEnumLiteral(sensorTypeEEnum, SensorType.BEACONS);
		addEEnumLiteral(sensorTypeEEnum, SensorType.MANUAL_INPUT);
		addEEnumLiteral(sensorTypeEEnum, SensorType.PROGRAM_MONITORY);

		initEEnum(configurationTypeEEnum, ConfigurationType.class, "ConfigurationType");
		addEEnumLiteral(configurationTypeEEnum, ConfigurationType.NOT_DEFINED);
		addEEnumLiteral(configurationTypeEEnum, ConfigurationType.ACTIVE);
		addEEnumLiteral(configurationTypeEEnum, ConfigurationType.PASIVE);
		addEEnumLiteral(configurationTypeEEnum, ConfigurationType.DEFAULT);

		initEEnum(executionTypeEEnum, ExecutionType.class, "ExecutionType");
		addEEnumLiteral(executionTypeEEnum, ExecutionType.NOT_DEFINED);
		addEEnumLiteral(executionTypeEEnum, ExecutionType.ACTIVE);
		addEEnumLiteral(executionTypeEEnum, ExecutionType.PASIVE);

		// Create resource
		createResource(eNS_URI);
	}

} //Cams2024PackageImpl
