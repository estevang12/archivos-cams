/**
 */
package cams2024.impl;

import cams2024.Cams2024Package;
import cams2024.ConcretSensor;
import cams2024.ConfigurationType;
import cams2024.ExecutionType;
import cams2024.PresitionMarginValue;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Concret Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link cams2024.impl.ConcretSensorImpl#getValue_of_configuratio_type <em>Value of configuratio type</em>}</li>
 *   <li>{@link cams2024.impl.ConcretSensorImpl#getExecutionType <em>Execution Type</em>}</li>
 *   <li>{@link cams2024.impl.ConcretSensorImpl#getPresitionmarginvalue <em>Presitionmarginvalue</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConcretSensorImpl extends MinimalEObjectImpl.Container implements ConcretSensor {
	/**
	 * The default value of the '{@link #getValue_of_configuratio_type() <em>Value of configuratio type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue_of_configuratio_type()
	 * @generated
	 * @ordered
	 */
	protected static final ConfigurationType VALUE_OF_CONFIGURATIO_TYPE_EDEFAULT = ConfigurationType.NOT_DEFINED;

	/**
	 * The cached value of the '{@link #getValue_of_configuratio_type() <em>Value of configuratio type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue_of_configuratio_type()
	 * @generated
	 * @ordered
	 */
	protected ConfigurationType value_of_configuratio_type = VALUE_OF_CONFIGURATIO_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getExecutionType() <em>Execution Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExecutionType()
	 * @generated
	 * @ordered
	 */
	protected static final ExecutionType EXECUTION_TYPE_EDEFAULT = ExecutionType.NOT_DEFINED;

	/**
	 * The cached value of the '{@link #getExecutionType() <em>Execution Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExecutionType()
	 * @generated
	 * @ordered
	 */
	protected ExecutionType executionType = EXECUTION_TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPresitionmarginvalue() <em>Presitionmarginvalue</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPresitionmarginvalue()
	 * @generated
	 * @ordered
	 */
	protected EList<PresitionMarginValue> presitionmarginvalue;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConcretSensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cams2024Package.Literals.CONCRET_SENSOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PresitionMarginValue> getPresitionmarginvalue() {
		if (presitionmarginvalue == null) {
			presitionmarginvalue = new EObjectContainmentEList<PresitionMarginValue>(PresitionMarginValue.class, this,
					Cams2024Package.CONCRET_SENSOR__PRESITIONMARGINVALUE);
		}
		return presitionmarginvalue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cams2024Package.CONCRET_SENSOR__PRESITIONMARGINVALUE:
			return ((InternalEList<?>) getPresitionmarginvalue()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConfigurationType getValue_of_configuratio_type() {
		return value_of_configuratio_type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setValue_of_configuratio_type(ConfigurationType newValue_of_configuratio_type) {
		ConfigurationType oldValue_of_configuratio_type = value_of_configuratio_type;
		value_of_configuratio_type = newValue_of_configuratio_type == null ? VALUE_OF_CONFIGURATIO_TYPE_EDEFAULT
				: newValue_of_configuratio_type;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cams2024Package.CONCRET_SENSOR__VALUE_OF_CONFIGURATIO_TYPE, oldValue_of_configuratio_type,
					value_of_configuratio_type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ExecutionType getExecutionType() {
		return executionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setExecutionType(ExecutionType newExecutionType) {
		ExecutionType oldExecutionType = executionType;
		executionType = newExecutionType == null ? EXECUTION_TYPE_EDEFAULT : newExecutionType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cams2024Package.CONCRET_SENSOR__EXECUTION_TYPE,
					oldExecutionType, executionType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cams2024Package.CONCRET_SENSOR__VALUE_OF_CONFIGURATIO_TYPE:
			return getValue_of_configuratio_type();
		case Cams2024Package.CONCRET_SENSOR__EXECUTION_TYPE:
			return getExecutionType();
		case Cams2024Package.CONCRET_SENSOR__PRESITIONMARGINVALUE:
			return getPresitionmarginvalue();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cams2024Package.CONCRET_SENSOR__VALUE_OF_CONFIGURATIO_TYPE:
			setValue_of_configuratio_type((ConfigurationType) newValue);
			return;
		case Cams2024Package.CONCRET_SENSOR__EXECUTION_TYPE:
			setExecutionType((ExecutionType) newValue);
			return;
		case Cams2024Package.CONCRET_SENSOR__PRESITIONMARGINVALUE:
			getPresitionmarginvalue().clear();
			getPresitionmarginvalue().addAll((Collection<? extends PresitionMarginValue>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cams2024Package.CONCRET_SENSOR__VALUE_OF_CONFIGURATIO_TYPE:
			setValue_of_configuratio_type(VALUE_OF_CONFIGURATIO_TYPE_EDEFAULT);
			return;
		case Cams2024Package.CONCRET_SENSOR__EXECUTION_TYPE:
			setExecutionType(EXECUTION_TYPE_EDEFAULT);
			return;
		case Cams2024Package.CONCRET_SENSOR__PRESITIONMARGINVALUE:
			getPresitionmarginvalue().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cams2024Package.CONCRET_SENSOR__VALUE_OF_CONFIGURATIO_TYPE:
			return value_of_configuratio_type != VALUE_OF_CONFIGURATIO_TYPE_EDEFAULT;
		case Cams2024Package.CONCRET_SENSOR__EXECUTION_TYPE:
			return executionType != EXECUTION_TYPE_EDEFAULT;
		case Cams2024Package.CONCRET_SENSOR__PRESITIONMARGINVALUE:
			return presitionmarginvalue != null && !presitionmarginvalue.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (value_of_configuratio_type: ");
		result.append(value_of_configuratio_type);
		result.append(", ExecutionType: ");
		result.append(executionType);
		result.append(')');
		return result.toString();
	}

} //ConcretSensorImpl
