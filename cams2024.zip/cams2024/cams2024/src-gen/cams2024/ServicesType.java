/**
 */
package cams2024;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Services Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see cams2024.Cams2024Package#getServicesType()
 * @model
 * @generated
 */
public enum ServicesType implements Enumerator {
	/**
	 * The '<em><b>Not Defined</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NOT_DEFINED_VALUE
	 * @generated
	 * @ordered
	 */
	NOT_DEFINED(0, "NotDefined", "NotDefined"),

	/**
	 * The '<em><b>Service1</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SERVICE1_VALUE
	 * @generated
	 * @ordered
	 */
	SERVICE1(1, "Service1", "Service1"),

	/**
	 * The '<em><b>Service2</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SERVICE2_VALUE
	 * @generated
	 * @ordered
	 */
	SERVICE2(2, "Service2", "Service2"),

	/**
	 * The '<em><b>Azure Maps</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #AZURE_MAPS_VALUE
	 * @generated
	 * @ordered
	 */
	AZURE_MAPS(3, "Azure_Maps", "Azure_Maps");

	/**
	 * The '<em><b>Not Defined</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NOT_DEFINED
	 * @model name="NotDefined"
	 * @generated
	 * @ordered
	 */
	public static final int NOT_DEFINED_VALUE = 0;

	/**
	 * The '<em><b>Service1</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SERVICE1
	 * @model name="Service1"
	 * @generated
	 * @ordered
	 */
	public static final int SERVICE1_VALUE = 1;

	/**
	 * The '<em><b>Service2</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SERVICE2
	 * @model name="Service2"
	 * @generated
	 * @ordered
	 */
	public static final int SERVICE2_VALUE = 2;

	/**
	 * The '<em><b>Azure Maps</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #AZURE_MAPS
	 * @model name="Azure_Maps"
	 * @generated
	 * @ordered
	 */
	public static final int AZURE_MAPS_VALUE = 3;

	/**
	 * An array of all the '<em><b>Services Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final ServicesType[] VALUES_ARRAY = new ServicesType[] { NOT_DEFINED, SERVICE1, SERVICE2,
			AZURE_MAPS, };

	/**
	 * A public read-only list of all the '<em><b>Services Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<ServicesType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Services Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ServicesType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ServicesType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Services Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ServicesType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ServicesType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Services Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ServicesType get(int value) {
		switch (value) {
		case NOT_DEFINED_VALUE:
			return NOT_DEFINED;
		case SERVICE1_VALUE:
			return SERVICE1;
		case SERVICE2_VALUE:
			return SERVICE2;
		case AZURE_MAPS_VALUE:
			return AZURE_MAPS;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private ServicesType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //ServicesType
