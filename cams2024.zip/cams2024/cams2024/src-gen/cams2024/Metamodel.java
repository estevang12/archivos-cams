/**
 */
package cams2024;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Metamodel</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link cams2024.Metamodel#getAwareobject <em>Awareobject</em>}</li>
 *   <li>{@link cams2024.Metamodel#getContextfeature <em>Contextfeature</em>}</li>
 *   <li>{@link cams2024.Metamodel#getAbstractsensor <em>Abstractsensor</em>}</li>
 *   <li>{@link cams2024.Metamodel#getRelevancevalue <em>Relevancevalue</em>}</li>
 *   <li>{@link cams2024.Metamodel#getCategoryvalue <em>Categoryvalue</em>}</li>
 *   <li>{@link cams2024.Metamodel#getRule <em>Rule</em>}</li>
 *   <li>{@link cams2024.Metamodel#getConcretsensor <em>Concretsensor</em>}</li>
 *   <li>{@link cams2024.Metamodel#getPresitionmarginvalue <em>Presitionmarginvalue</em>}</li>
 *   <li>{@link cams2024.Metamodel#getService <em>Service</em>}</li>
 * </ul>
 *
 * @see cams2024.Cams2024Package#getMetamodel()
 * @model
 * @generated
 */
public interface Metamodel extends EObject {
	/**
	 * Returns the value of the '<em><b>Awareobject</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.AwareObject}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Awareobject</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getMetamodel_Awareobject()
	 * @model containment="true"
	 * @generated
	 */
	EList<AwareObject> getAwareobject();

	/**
	 * Returns the value of the '<em><b>Contextfeature</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.ContextFeature}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contextfeature</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getMetamodel_Contextfeature()
	 * @model containment="true"
	 * @generated
	 */
	EList<ContextFeature> getContextfeature();

	/**
	 * Returns the value of the '<em><b>Abstractsensor</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.AbstractSensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Abstractsensor</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getMetamodel_Abstractsensor()
	 * @model containment="true"
	 * @generated
	 */
	EList<AbstractSensor> getAbstractsensor();

	/**
	 * Returns the value of the '<em><b>Relevancevalue</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.RelevanceValue}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Relevancevalue</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getMetamodel_Relevancevalue()
	 * @model containment="true"
	 * @generated
	 */
	EList<RelevanceValue> getRelevancevalue();

	/**
	 * Returns the value of the '<em><b>Categoryvalue</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.CategoryValue}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Categoryvalue</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getMetamodel_Categoryvalue()
	 * @model containment="true"
	 * @generated
	 */
	EList<CategoryValue> getCategoryvalue();

	/**
	 * Returns the value of the '<em><b>Rule</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.Rule}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rule</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getMetamodel_Rule()
	 * @model containment="true"
	 * @generated
	 */
	EList<Rule> getRule();

	/**
	 * Returns the value of the '<em><b>Concretsensor</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.ConcretSensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Concretsensor</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getMetamodel_Concretsensor()
	 * @model containment="true"
	 * @generated
	 */
	EList<ConcretSensor> getConcretsensor();

	/**
	 * Returns the value of the '<em><b>Presitionmarginvalue</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.PresitionMarginValue}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Presitionmarginvalue</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getMetamodel_Presitionmarginvalue()
	 * @model containment="true"
	 * @generated
	 */
	EList<PresitionMarginValue> getPresitionmarginvalue();

	/**
	 * Returns the value of the '<em><b>Service</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.Service}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getMetamodel_Service()
	 * @model containment="true"
	 * @generated
	 */
	EList<Service> getService();

} // Metamodel
