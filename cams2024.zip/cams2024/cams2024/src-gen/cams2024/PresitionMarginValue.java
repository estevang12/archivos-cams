/**
 */
package cams2024;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Presition Margin Value</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link cams2024.PresitionMarginValue#getV1 <em>V1</em>}</li>
 *   <li>{@link cams2024.PresitionMarginValue#getVF <em>VF</em>}</li>
 * </ul>
 *
 * @see cams2024.Cams2024Package#getPresitionMarginValue()
 * @model
 * @generated
 */
public interface PresitionMarginValue extends EObject {
	/**
	 * Returns the value of the '<em><b>V1</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>V1</em>' attribute.
	 * @see #setV1(double)
	 * @see cams2024.Cams2024Package#getPresitionMarginValue_V1()
	 * @model default="0.0" dataType="org.eclipse.emf.ecore.xml.type.Double"
	 * @generated
	 */
	double getV1();

	/**
	 * Sets the value of the '{@link cams2024.PresitionMarginValue#getV1 <em>V1</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>V1</em>' attribute.
	 * @see #getV1()
	 * @generated
	 */
	void setV1(double value);

	/**
	 * Returns the value of the '<em><b>VF</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>VF</em>' attribute.
	 * @see #setVF(double)
	 * @see cams2024.Cams2024Package#getPresitionMarginValue_VF()
	 * @model default="0.0" dataType="org.eclipse.emf.ecore.xml.type.Double"
	 * @generated
	 */
	double getVF();

	/**
	 * Sets the value of the '{@link cams2024.PresitionMarginValue#getVF <em>VF</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>VF</em>' attribute.
	 * @see #getVF()
	 * @generated
	 */
	void setVF(double value);

} // PresitionMarginValue
