/**
 */
package cams2024;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Relevance Value</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link cams2024.RelevanceValue#getValue_or_range <em>Value or range</em>}</li>
 * </ul>
 *
 * @see cams2024.Cams2024Package#getRelevanceValue()
 * @model
 * @generated
 */
public interface RelevanceValue extends EObject {
	/**
	 * Returns the value of the '<em><b>Value or range</b></em>' attribute.
	 * The literals are from the enumeration {@link cams2024.RelValue}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value or range</em>' attribute.
	 * @see cams2024.RelValue
	 * @see #setValue_or_range(RelValue)
	 * @see cams2024.Cams2024Package#getRelevanceValue_Value_or_range()
	 * @model
	 * @generated
	 */
	RelValue getValue_or_range();

	/**
	 * Sets the value of the '{@link cams2024.RelevanceValue#getValue_or_range <em>Value or range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value or range</em>' attribute.
	 * @see cams2024.RelValue
	 * @see #getValue_or_range()
	 * @generated
	 */
	void setValue_or_range(RelValue value);

} // RelevanceValue
