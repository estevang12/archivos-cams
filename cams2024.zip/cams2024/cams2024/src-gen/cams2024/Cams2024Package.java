/**
 */
package cams2024;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see cams2024.Cams2024Factory
 * @model kind="package"
 * @generated
 */
public interface Cams2024Package extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "cams2024";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/cams2024";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "cams2024";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Cams2024Package eINSTANCE = cams2024.impl.Cams2024PackageImpl.init();

	/**
	 * The meta object id for the '{@link cams2024.impl.MetamodelImpl <em>Metamodel</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.impl.MetamodelImpl
	 * @see cams2024.impl.Cams2024PackageImpl#getMetamodel()
	 * @generated
	 */
	int METAMODEL = 0;

	/**
	 * The feature id for the '<em><b>Awareobject</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL__AWAREOBJECT = 0;

	/**
	 * The feature id for the '<em><b>Contextfeature</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL__CONTEXTFEATURE = 1;

	/**
	 * The feature id for the '<em><b>Abstractsensor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL__ABSTRACTSENSOR = 2;

	/**
	 * The feature id for the '<em><b>Relevancevalue</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL__RELEVANCEVALUE = 3;

	/**
	 * The feature id for the '<em><b>Categoryvalue</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL__CATEGORYVALUE = 4;

	/**
	 * The feature id for the '<em><b>Rule</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL__RULE = 5;

	/**
	 * The feature id for the '<em><b>Concretsensor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL__CONCRETSENSOR = 6;

	/**
	 * The feature id for the '<em><b>Presitionmarginvalue</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL__PRESITIONMARGINVALUE = 7;

	/**
	 * The feature id for the '<em><b>Service</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL__SERVICE = 8;

	/**
	 * The number of structural features of the '<em>Metamodel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL_FEATURE_COUNT = 9;

	/**
	 * The number of operations of the '<em>Metamodel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cams2024.impl.AwareObjectImpl <em>Aware Object</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.impl.AwareObjectImpl
	 * @see cams2024.impl.Cams2024PackageImpl#getAwareObject()
	 * @generated
	 */
	int AWARE_OBJECT = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AWARE_OBJECT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Has contextfeature</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AWARE_OBJECT__HAS_CONTEXTFEATURE = 1;

	/**
	 * The feature id for the '<em><b>Belong categoryvalue</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AWARE_OBJECT__BELONG_CATEGORYVALUE = 2;

	/**
	 * The number of structural features of the '<em>Aware Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AWARE_OBJECT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Aware Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AWARE_OBJECT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cams2024.impl.ContextFeatureImpl <em>Context Feature</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.impl.ContextFeatureImpl
	 * @see cams2024.impl.Cams2024PackageImpl#getContextFeature()
	 * @generated
	 */
	int CONTEXT_FEATURE = 2;

	/**
	 * The feature id for the '<em><b>Observer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_FEATURE__OBSERVER = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_FEATURE__NAME = 1;

	/**
	 * The feature id for the '<em><b>Latitud</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_FEATURE__LATITUD = 2;

	/**
	 * The feature id for the '<em><b>Longitud</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_FEATURE__LONGITUD = 3;

	/**
	 * The feature id for the '<em><b>Has abstractsensor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_FEATURE__HAS_ABSTRACTSENSOR = 4;

	/**
	 * The feature id for the '<em><b>Has relevancevalue</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_FEATURE__HAS_RELEVANCEVALUE = 5;

	/**
	 * The number of structural features of the '<em>Context Feature</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_FEATURE_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Context Feature</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_FEATURE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cams2024.impl.AbstractSensorImpl <em>Abstract Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.impl.AbstractSensorImpl
	 * @see cams2024.impl.Cams2024PackageImpl#getAbstractSensor()
	 * @generated
	 */
	int ABSTRACT_SENSOR = 3;

	/**
	 * The feature id for the '<em><b>Sensor Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SENSOR__SENSOR_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Corresponds to concretsensor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SENSOR__CORRESPONDS_TO_CONCRETSENSOR = 1;

	/**
	 * The number of structural features of the '<em>Abstract Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SENSOR_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Abstract Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SENSOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cams2024.impl.RelevanceValueImpl <em>Relevance Value</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.impl.RelevanceValueImpl
	 * @see cams2024.impl.Cams2024PackageImpl#getRelevanceValue()
	 * @generated
	 */
	int RELEVANCE_VALUE = 4;

	/**
	 * The feature id for the '<em><b>Value or range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELEVANCE_VALUE__VALUE_OR_RANGE = 0;

	/**
	 * The number of structural features of the '<em>Relevance Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELEVANCE_VALUE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Relevance Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELEVANCE_VALUE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cams2024.impl.CategoryValueImpl <em>Category Value</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.impl.CategoryValueImpl
	 * @see cams2024.impl.Cams2024PackageImpl#getCategoryValue()
	 * @generated
	 */
	int CATEGORY_VALUE = 5;

	/**
	 * The feature id for the '<em><b>Value of categ</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATEGORY_VALUE__VALUE_OF_CATEG = 0;

	/**
	 * The number of structural features of the '<em>Category Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATEGORY_VALUE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Category Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATEGORY_VALUE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cams2024.impl.RuleImpl <em>Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.impl.RuleImpl
	 * @see cams2024.impl.Cams2024PackageImpl#getRule()
	 * @generated
	 */
	int RULE = 6;

	/**
	 * The feature id for the '<em><b>Executes</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE__EXECUTES = 0;

	/**
	 * The feature id for the '<em><b>Rule description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE__RULE_DESCRIPTION = 1;

	/**
	 * The feature id for the '<em><b>Update</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE__UPDATE = 2;

	/**
	 * The number of structural features of the '<em>Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cams2024.impl.ConcretSensorImpl <em>Concret Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.impl.ConcretSensorImpl
	 * @see cams2024.impl.Cams2024PackageImpl#getConcretSensor()
	 * @generated
	 */
	int CONCRET_SENSOR = 7;

	/**
	 * The feature id for the '<em><b>Value of configuratio type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRET_SENSOR__VALUE_OF_CONFIGURATIO_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Execution Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRET_SENSOR__EXECUTION_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Presitionmarginvalue</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRET_SENSOR__PRESITIONMARGINVALUE = 2;

	/**
	 * The number of structural features of the '<em>Concret Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRET_SENSOR_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Concret Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCRET_SENSOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cams2024.impl.PresitionMarginValueImpl <em>Presition Margin Value</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.impl.PresitionMarginValueImpl
	 * @see cams2024.impl.Cams2024PackageImpl#getPresitionMarginValue()
	 * @generated
	 */
	int PRESITION_MARGIN_VALUE = 8;

	/**
	 * The feature id for the '<em><b>V1</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESITION_MARGIN_VALUE__V1 = 0;

	/**
	 * The feature id for the '<em><b>VF</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESITION_MARGIN_VALUE__VF = 1;

	/**
	 * The number of structural features of the '<em>Presition Margin Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESITION_MARGIN_VALUE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Presition Margin Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESITION_MARGIN_VALUE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cams2024.impl.ServiceImpl <em>Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.impl.ServiceImpl
	 * @see cams2024.impl.Cams2024PackageImpl#getService()
	 * @generated
	 */
	int SERVICE = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE__TYPE = 1;

	/**
	 * The number of structural features of the '<em>Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link cams2024.ServicesType <em>Services Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.ServicesType
	 * @see cams2024.impl.Cams2024PackageImpl#getServicesType()
	 * @generated
	 */
	int SERVICES_TYPE = 10;

	/**
	 * The meta object id for the '{@link cams2024.Categ_value <em>Categ value</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.Categ_value
	 * @see cams2024.impl.Cams2024PackageImpl#getCateg_value()
	 * @generated
	 */
	int CATEG_VALUE = 11;

	/**
	 * The meta object id for the '{@link cams2024.RelValue <em>Rel Value</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.RelValue
	 * @see cams2024.impl.Cams2024PackageImpl#getRelValue()
	 * @generated
	 */
	int REL_VALUE = 12;

	/**
	 * The meta object id for the '{@link cams2024.SensorType <em>Sensor Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.SensorType
	 * @see cams2024.impl.Cams2024PackageImpl#getSensorType()
	 * @generated
	 */
	int SENSOR_TYPE = 13;

	/**
	 * The meta object id for the '{@link cams2024.ConfigurationType <em>Configuration Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.ConfigurationType
	 * @see cams2024.impl.Cams2024PackageImpl#getConfigurationType()
	 * @generated
	 */
	int CONFIGURATION_TYPE = 14;

	/**
	 * The meta object id for the '{@link cams2024.ExecutionType <em>Execution Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see cams2024.ExecutionType
	 * @see cams2024.impl.Cams2024PackageImpl#getExecutionType()
	 * @generated
	 */
	int EXECUTION_TYPE = 15;

	/**
	 * Returns the meta object for class '{@link cams2024.Metamodel <em>Metamodel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Metamodel</em>'.
	 * @see cams2024.Metamodel
	 * @generated
	 */
	EClass getMetamodel();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.Metamodel#getAwareobject <em>Awareobject</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Awareobject</em>'.
	 * @see cams2024.Metamodel#getAwareobject()
	 * @see #getMetamodel()
	 * @generated
	 */
	EReference getMetamodel_Awareobject();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.Metamodel#getContextfeature <em>Contextfeature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Contextfeature</em>'.
	 * @see cams2024.Metamodel#getContextfeature()
	 * @see #getMetamodel()
	 * @generated
	 */
	EReference getMetamodel_Contextfeature();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.Metamodel#getAbstractsensor <em>Abstractsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Abstractsensor</em>'.
	 * @see cams2024.Metamodel#getAbstractsensor()
	 * @see #getMetamodel()
	 * @generated
	 */
	EReference getMetamodel_Abstractsensor();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.Metamodel#getRelevancevalue <em>Relevancevalue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Relevancevalue</em>'.
	 * @see cams2024.Metamodel#getRelevancevalue()
	 * @see #getMetamodel()
	 * @generated
	 */
	EReference getMetamodel_Relevancevalue();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.Metamodel#getCategoryvalue <em>Categoryvalue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Categoryvalue</em>'.
	 * @see cams2024.Metamodel#getCategoryvalue()
	 * @see #getMetamodel()
	 * @generated
	 */
	EReference getMetamodel_Categoryvalue();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.Metamodel#getRule <em>Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Rule</em>'.
	 * @see cams2024.Metamodel#getRule()
	 * @see #getMetamodel()
	 * @generated
	 */
	EReference getMetamodel_Rule();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.Metamodel#getConcretsensor <em>Concretsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Concretsensor</em>'.
	 * @see cams2024.Metamodel#getConcretsensor()
	 * @see #getMetamodel()
	 * @generated
	 */
	EReference getMetamodel_Concretsensor();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.Metamodel#getPresitionmarginvalue <em>Presitionmarginvalue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Presitionmarginvalue</em>'.
	 * @see cams2024.Metamodel#getPresitionmarginvalue()
	 * @see #getMetamodel()
	 * @generated
	 */
	EReference getMetamodel_Presitionmarginvalue();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.Metamodel#getService <em>Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Service</em>'.
	 * @see cams2024.Metamodel#getService()
	 * @see #getMetamodel()
	 * @generated
	 */
	EReference getMetamodel_Service();

	/**
	 * Returns the meta object for class '{@link cams2024.AwareObject <em>Aware Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Aware Object</em>'.
	 * @see cams2024.AwareObject
	 * @generated
	 */
	EClass getAwareObject();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.AwareObject#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see cams2024.AwareObject#getName()
	 * @see #getAwareObject()
	 * @generated
	 */
	EAttribute getAwareObject_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.AwareObject#getHas_contextfeature <em>Has contextfeature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Has contextfeature</em>'.
	 * @see cams2024.AwareObject#getHas_contextfeature()
	 * @see #getAwareObject()
	 * @generated
	 */
	EReference getAwareObject_Has_contextfeature();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.AwareObject#getBelong_categoryvalue <em>Belong categoryvalue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Belong categoryvalue</em>'.
	 * @see cams2024.AwareObject#getBelong_categoryvalue()
	 * @see #getAwareObject()
	 * @generated
	 */
	EReference getAwareObject_Belong_categoryvalue();

	/**
	 * Returns the meta object for class '{@link cams2024.ContextFeature <em>Context Feature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Context Feature</em>'.
	 * @see cams2024.ContextFeature
	 * @generated
	 */
	EClass getContextFeature();

	/**
	 * Returns the meta object for the reference list '{@link cams2024.ContextFeature#getObserver <em>Observer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Observer</em>'.
	 * @see cams2024.ContextFeature#getObserver()
	 * @see #getContextFeature()
	 * @generated
	 */
	EReference getContextFeature_Observer();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.ContextFeature#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see cams2024.ContextFeature#getName()
	 * @see #getContextFeature()
	 * @generated
	 */
	EAttribute getContextFeature_Name();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.ContextFeature#getLatitud <em>Latitud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Latitud</em>'.
	 * @see cams2024.ContextFeature#getLatitud()
	 * @see #getContextFeature()
	 * @generated
	 */
	EAttribute getContextFeature_Latitud();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.ContextFeature#getLongitud <em>Longitud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Longitud</em>'.
	 * @see cams2024.ContextFeature#getLongitud()
	 * @see #getContextFeature()
	 * @generated
	 */
	EAttribute getContextFeature_Longitud();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.ContextFeature#getHas_abstractsensor <em>Has abstractsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Has abstractsensor</em>'.
	 * @see cams2024.ContextFeature#getHas_abstractsensor()
	 * @see #getContextFeature()
	 * @generated
	 */
	EReference getContextFeature_Has_abstractsensor();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.ContextFeature#getHas_relevancevalue <em>Has relevancevalue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Has relevancevalue</em>'.
	 * @see cams2024.ContextFeature#getHas_relevancevalue()
	 * @see #getContextFeature()
	 * @generated
	 */
	EReference getContextFeature_Has_relevancevalue();

	/**
	 * Returns the meta object for class '{@link cams2024.AbstractSensor <em>Abstract Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Sensor</em>'.
	 * @see cams2024.AbstractSensor
	 * @generated
	 */
	EClass getAbstractSensor();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.AbstractSensor#getSensorType <em>Sensor Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sensor Type</em>'.
	 * @see cams2024.AbstractSensor#getSensorType()
	 * @see #getAbstractSensor()
	 * @generated
	 */
	EAttribute getAbstractSensor_SensorType();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.AbstractSensor#getCorresponds_to_concretsensor <em>Corresponds to concretsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Corresponds to concretsensor</em>'.
	 * @see cams2024.AbstractSensor#getCorresponds_to_concretsensor()
	 * @see #getAbstractSensor()
	 * @generated
	 */
	EReference getAbstractSensor_Corresponds_to_concretsensor();

	/**
	 * Returns the meta object for class '{@link cams2024.RelevanceValue <em>Relevance Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Relevance Value</em>'.
	 * @see cams2024.RelevanceValue
	 * @generated
	 */
	EClass getRelevanceValue();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.RelevanceValue#getValue_or_range <em>Value or range</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value or range</em>'.
	 * @see cams2024.RelevanceValue#getValue_or_range()
	 * @see #getRelevanceValue()
	 * @generated
	 */
	EAttribute getRelevanceValue_Value_or_range();

	/**
	 * Returns the meta object for class '{@link cams2024.CategoryValue <em>Category Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Category Value</em>'.
	 * @see cams2024.CategoryValue
	 * @generated
	 */
	EClass getCategoryValue();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.CategoryValue#getValue_of_categ <em>Value of categ</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value of categ</em>'.
	 * @see cams2024.CategoryValue#getValue_of_categ()
	 * @see #getCategoryValue()
	 * @generated
	 */
	EAttribute getCategoryValue_Value_of_categ();

	/**
	 * Returns the meta object for class '{@link cams2024.Rule <em>Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Rule</em>'.
	 * @see cams2024.Rule
	 * @generated
	 */
	EClass getRule();

	/**
	 * Returns the meta object for the reference '{@link cams2024.Rule#getExecutes <em>Executes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Executes</em>'.
	 * @see cams2024.Rule#getExecutes()
	 * @see #getRule()
	 * @generated
	 */
	EReference getRule_Executes();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.Rule#getRule_description <em>Rule description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rule description</em>'.
	 * @see cams2024.Rule#getRule_description()
	 * @see #getRule()
	 * @generated
	 */
	EAttribute getRule_Rule_description();

	/**
	 * Returns the meta object for the reference list '{@link cams2024.Rule#getUpdate <em>Update</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Update</em>'.
	 * @see cams2024.Rule#getUpdate()
	 * @see #getRule()
	 * @generated
	 */
	EReference getRule_Update();

	/**
	 * Returns the meta object for class '{@link cams2024.ConcretSensor <em>Concret Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Concret Sensor</em>'.
	 * @see cams2024.ConcretSensor
	 * @generated
	 */
	EClass getConcretSensor();

	/**
	 * Returns the meta object for the containment reference list '{@link cams2024.ConcretSensor#getPresitionmarginvalue <em>Presitionmarginvalue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Presitionmarginvalue</em>'.
	 * @see cams2024.ConcretSensor#getPresitionmarginvalue()
	 * @see #getConcretSensor()
	 * @generated
	 */
	EReference getConcretSensor_Presitionmarginvalue();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.ConcretSensor#getValue_of_configuratio_type <em>Value of configuratio type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value of configuratio type</em>'.
	 * @see cams2024.ConcretSensor#getValue_of_configuratio_type()
	 * @see #getConcretSensor()
	 * @generated
	 */
	EAttribute getConcretSensor_Value_of_configuratio_type();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.ConcretSensor#getExecutionType <em>Execution Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Execution Type</em>'.
	 * @see cams2024.ConcretSensor#getExecutionType()
	 * @see #getConcretSensor()
	 * @generated
	 */
	EAttribute getConcretSensor_ExecutionType();

	/**
	 * Returns the meta object for class '{@link cams2024.PresitionMarginValue <em>Presition Margin Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Presition Margin Value</em>'.
	 * @see cams2024.PresitionMarginValue
	 * @generated
	 */
	EClass getPresitionMarginValue();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.PresitionMarginValue#getV1 <em>V1</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>V1</em>'.
	 * @see cams2024.PresitionMarginValue#getV1()
	 * @see #getPresitionMarginValue()
	 * @generated
	 */
	EAttribute getPresitionMarginValue_V1();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.PresitionMarginValue#getVF <em>VF</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>VF</em>'.
	 * @see cams2024.PresitionMarginValue#getVF()
	 * @see #getPresitionMarginValue()
	 * @generated
	 */
	EAttribute getPresitionMarginValue_VF();

	/**
	 * Returns the meta object for class '{@link cams2024.Service <em>Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service</em>'.
	 * @see cams2024.Service
	 * @generated
	 */
	EClass getService();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.Service#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see cams2024.Service#getName()
	 * @see #getService()
	 * @generated
	 */
	EAttribute getService_Name();

	/**
	 * Returns the meta object for the attribute '{@link cams2024.Service#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see cams2024.Service#getType()
	 * @see #getService()
	 * @generated
	 */
	EAttribute getService_Type();

	/**
	 * Returns the meta object for enum '{@link cams2024.ServicesType <em>Services Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Services Type</em>'.
	 * @see cams2024.ServicesType
	 * @generated
	 */
	EEnum getServicesType();

	/**
	 * Returns the meta object for enum '{@link cams2024.Categ_value <em>Categ value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Categ value</em>'.
	 * @see cams2024.Categ_value
	 * @generated
	 */
	EEnum getCateg_value();

	/**
	 * Returns the meta object for enum '{@link cams2024.RelValue <em>Rel Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Rel Value</em>'.
	 * @see cams2024.RelValue
	 * @generated
	 */
	EEnum getRelValue();

	/**
	 * Returns the meta object for enum '{@link cams2024.SensorType <em>Sensor Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Sensor Type</em>'.
	 * @see cams2024.SensorType
	 * @generated
	 */
	EEnum getSensorType();

	/**
	 * Returns the meta object for enum '{@link cams2024.ConfigurationType <em>Configuration Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Configuration Type</em>'.
	 * @see cams2024.ConfigurationType
	 * @generated
	 */
	EEnum getConfigurationType();

	/**
	 * Returns the meta object for enum '{@link cams2024.ExecutionType <em>Execution Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Execution Type</em>'.
	 * @see cams2024.ExecutionType
	 * @generated
	 */
	EEnum getExecutionType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Cams2024Factory getCams2024Factory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link cams2024.impl.MetamodelImpl <em>Metamodel</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.impl.MetamodelImpl
		 * @see cams2024.impl.Cams2024PackageImpl#getMetamodel()
		 * @generated
		 */
		EClass METAMODEL = eINSTANCE.getMetamodel();

		/**
		 * The meta object literal for the '<em><b>Awareobject</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METAMODEL__AWAREOBJECT = eINSTANCE.getMetamodel_Awareobject();

		/**
		 * The meta object literal for the '<em><b>Contextfeature</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METAMODEL__CONTEXTFEATURE = eINSTANCE.getMetamodel_Contextfeature();

		/**
		 * The meta object literal for the '<em><b>Abstractsensor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METAMODEL__ABSTRACTSENSOR = eINSTANCE.getMetamodel_Abstractsensor();

		/**
		 * The meta object literal for the '<em><b>Relevancevalue</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METAMODEL__RELEVANCEVALUE = eINSTANCE.getMetamodel_Relevancevalue();

		/**
		 * The meta object literal for the '<em><b>Categoryvalue</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METAMODEL__CATEGORYVALUE = eINSTANCE.getMetamodel_Categoryvalue();

		/**
		 * The meta object literal for the '<em><b>Rule</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METAMODEL__RULE = eINSTANCE.getMetamodel_Rule();

		/**
		 * The meta object literal for the '<em><b>Concretsensor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METAMODEL__CONCRETSENSOR = eINSTANCE.getMetamodel_Concretsensor();

		/**
		 * The meta object literal for the '<em><b>Presitionmarginvalue</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METAMODEL__PRESITIONMARGINVALUE = eINSTANCE.getMetamodel_Presitionmarginvalue();

		/**
		 * The meta object literal for the '<em><b>Service</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METAMODEL__SERVICE = eINSTANCE.getMetamodel_Service();

		/**
		 * The meta object literal for the '{@link cams2024.impl.AwareObjectImpl <em>Aware Object</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.impl.AwareObjectImpl
		 * @see cams2024.impl.Cams2024PackageImpl#getAwareObject()
		 * @generated
		 */
		EClass AWARE_OBJECT = eINSTANCE.getAwareObject();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AWARE_OBJECT__NAME = eINSTANCE.getAwareObject_Name();

		/**
		 * The meta object literal for the '<em><b>Has contextfeature</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AWARE_OBJECT__HAS_CONTEXTFEATURE = eINSTANCE.getAwareObject_Has_contextfeature();

		/**
		 * The meta object literal for the '<em><b>Belong categoryvalue</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AWARE_OBJECT__BELONG_CATEGORYVALUE = eINSTANCE.getAwareObject_Belong_categoryvalue();

		/**
		 * The meta object literal for the '{@link cams2024.impl.ContextFeatureImpl <em>Context Feature</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.impl.ContextFeatureImpl
		 * @see cams2024.impl.Cams2024PackageImpl#getContextFeature()
		 * @generated
		 */
		EClass CONTEXT_FEATURE = eINSTANCE.getContextFeature();

		/**
		 * The meta object literal for the '<em><b>Observer</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTEXT_FEATURE__OBSERVER = eINSTANCE.getContextFeature_Observer();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTEXT_FEATURE__NAME = eINSTANCE.getContextFeature_Name();

		/**
		 * The meta object literal for the '<em><b>Latitud</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTEXT_FEATURE__LATITUD = eINSTANCE.getContextFeature_Latitud();

		/**
		 * The meta object literal for the '<em><b>Longitud</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTEXT_FEATURE__LONGITUD = eINSTANCE.getContextFeature_Longitud();

		/**
		 * The meta object literal for the '<em><b>Has abstractsensor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTEXT_FEATURE__HAS_ABSTRACTSENSOR = eINSTANCE.getContextFeature_Has_abstractsensor();

		/**
		 * The meta object literal for the '<em><b>Has relevancevalue</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTEXT_FEATURE__HAS_RELEVANCEVALUE = eINSTANCE.getContextFeature_Has_relevancevalue();

		/**
		 * The meta object literal for the '{@link cams2024.impl.AbstractSensorImpl <em>Abstract Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.impl.AbstractSensorImpl
		 * @see cams2024.impl.Cams2024PackageImpl#getAbstractSensor()
		 * @generated
		 */
		EClass ABSTRACT_SENSOR = eINSTANCE.getAbstractSensor();

		/**
		 * The meta object literal for the '<em><b>Sensor Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_SENSOR__SENSOR_TYPE = eINSTANCE.getAbstractSensor_SensorType();

		/**
		 * The meta object literal for the '<em><b>Corresponds to concretsensor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_SENSOR__CORRESPONDS_TO_CONCRETSENSOR = eINSTANCE
				.getAbstractSensor_Corresponds_to_concretsensor();

		/**
		 * The meta object literal for the '{@link cams2024.impl.RelevanceValueImpl <em>Relevance Value</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.impl.RelevanceValueImpl
		 * @see cams2024.impl.Cams2024PackageImpl#getRelevanceValue()
		 * @generated
		 */
		EClass RELEVANCE_VALUE = eINSTANCE.getRelevanceValue();

		/**
		 * The meta object literal for the '<em><b>Value or range</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RELEVANCE_VALUE__VALUE_OR_RANGE = eINSTANCE.getRelevanceValue_Value_or_range();

		/**
		 * The meta object literal for the '{@link cams2024.impl.CategoryValueImpl <em>Category Value</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.impl.CategoryValueImpl
		 * @see cams2024.impl.Cams2024PackageImpl#getCategoryValue()
		 * @generated
		 */
		EClass CATEGORY_VALUE = eINSTANCE.getCategoryValue();

		/**
		 * The meta object literal for the '<em><b>Value of categ</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CATEGORY_VALUE__VALUE_OF_CATEG = eINSTANCE.getCategoryValue_Value_of_categ();

		/**
		 * The meta object literal for the '{@link cams2024.impl.RuleImpl <em>Rule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.impl.RuleImpl
		 * @see cams2024.impl.Cams2024PackageImpl#getRule()
		 * @generated
		 */
		EClass RULE = eINSTANCE.getRule();

		/**
		 * The meta object literal for the '<em><b>Executes</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RULE__EXECUTES = eINSTANCE.getRule_Executes();

		/**
		 * The meta object literal for the '<em><b>Rule description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RULE__RULE_DESCRIPTION = eINSTANCE.getRule_Rule_description();

		/**
		 * The meta object literal for the '<em><b>Update</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RULE__UPDATE = eINSTANCE.getRule_Update();

		/**
		 * The meta object literal for the '{@link cams2024.impl.ConcretSensorImpl <em>Concret Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.impl.ConcretSensorImpl
		 * @see cams2024.impl.Cams2024PackageImpl#getConcretSensor()
		 * @generated
		 */
		EClass CONCRET_SENSOR = eINSTANCE.getConcretSensor();

		/**
		 * The meta object literal for the '<em><b>Presitionmarginvalue</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONCRET_SENSOR__PRESITIONMARGINVALUE = eINSTANCE.getConcretSensor_Presitionmarginvalue();

		/**
		 * The meta object literal for the '<em><b>Value of configuratio type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONCRET_SENSOR__VALUE_OF_CONFIGURATIO_TYPE = eINSTANCE.getConcretSensor_Value_of_configuratio_type();

		/**
		 * The meta object literal for the '<em><b>Execution Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONCRET_SENSOR__EXECUTION_TYPE = eINSTANCE.getConcretSensor_ExecutionType();

		/**
		 * The meta object literal for the '{@link cams2024.impl.PresitionMarginValueImpl <em>Presition Margin Value</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.impl.PresitionMarginValueImpl
		 * @see cams2024.impl.Cams2024PackageImpl#getPresitionMarginValue()
		 * @generated
		 */
		EClass PRESITION_MARGIN_VALUE = eINSTANCE.getPresitionMarginValue();

		/**
		 * The meta object literal for the '<em><b>V1</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRESITION_MARGIN_VALUE__V1 = eINSTANCE.getPresitionMarginValue_V1();

		/**
		 * The meta object literal for the '<em><b>VF</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRESITION_MARGIN_VALUE__VF = eINSTANCE.getPresitionMarginValue_VF();

		/**
		 * The meta object literal for the '{@link cams2024.impl.ServiceImpl <em>Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.impl.ServiceImpl
		 * @see cams2024.impl.Cams2024PackageImpl#getService()
		 * @generated
		 */
		EClass SERVICE = eINSTANCE.getService();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVICE__NAME = eINSTANCE.getService_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVICE__TYPE = eINSTANCE.getService_Type();

		/**
		 * The meta object literal for the '{@link cams2024.ServicesType <em>Services Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.ServicesType
		 * @see cams2024.impl.Cams2024PackageImpl#getServicesType()
		 * @generated
		 */
		EEnum SERVICES_TYPE = eINSTANCE.getServicesType();

		/**
		 * The meta object literal for the '{@link cams2024.Categ_value <em>Categ value</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.Categ_value
		 * @see cams2024.impl.Cams2024PackageImpl#getCateg_value()
		 * @generated
		 */
		EEnum CATEG_VALUE = eINSTANCE.getCateg_value();

		/**
		 * The meta object literal for the '{@link cams2024.RelValue <em>Rel Value</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.RelValue
		 * @see cams2024.impl.Cams2024PackageImpl#getRelValue()
		 * @generated
		 */
		EEnum REL_VALUE = eINSTANCE.getRelValue();

		/**
		 * The meta object literal for the '{@link cams2024.SensorType <em>Sensor Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.SensorType
		 * @see cams2024.impl.Cams2024PackageImpl#getSensorType()
		 * @generated
		 */
		EEnum SENSOR_TYPE = eINSTANCE.getSensorType();

		/**
		 * The meta object literal for the '{@link cams2024.ConfigurationType <em>Configuration Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.ConfigurationType
		 * @see cams2024.impl.Cams2024PackageImpl#getConfigurationType()
		 * @generated
		 */
		EEnum CONFIGURATION_TYPE = eINSTANCE.getConfigurationType();

		/**
		 * The meta object literal for the '{@link cams2024.ExecutionType <em>Execution Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see cams2024.ExecutionType
		 * @see cams2024.impl.Cams2024PackageImpl#getExecutionType()
		 * @generated
		 */
		EEnum EXECUTION_TYPE = eINSTANCE.getExecutionType();

	}

} //Cams2024Package
