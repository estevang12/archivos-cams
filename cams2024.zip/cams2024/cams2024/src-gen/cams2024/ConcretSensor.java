/**
 */
package cams2024;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Concret Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link cams2024.ConcretSensor#getValue_of_configuratio_type <em>Value of configuratio type</em>}</li>
 *   <li>{@link cams2024.ConcretSensor#getExecutionType <em>Execution Type</em>}</li>
 *   <li>{@link cams2024.ConcretSensor#getPresitionmarginvalue <em>Presitionmarginvalue</em>}</li>
 * </ul>
 *
 * @see cams2024.Cams2024Package#getConcretSensor()
 * @model
 * @generated
 */
public interface ConcretSensor extends EObject {
	/**
	 * Returns the value of the '<em><b>Presitionmarginvalue</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.PresitionMarginValue}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Presitionmarginvalue</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getConcretSensor_Presitionmarginvalue()
	 * @model containment="true"
	 * @generated
	 */
	EList<PresitionMarginValue> getPresitionmarginvalue();

	/**
	 * Returns the value of the '<em><b>Value of configuratio type</b></em>' attribute.
	 * The literals are from the enumeration {@link cams2024.ConfigurationType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value of configuratio type</em>' attribute.
	 * @see cams2024.ConfigurationType
	 * @see #setValue_of_configuratio_type(ConfigurationType)
	 * @see cams2024.Cams2024Package#getConcretSensor_Value_of_configuratio_type()
	 * @model
	 * @generated
	 */
	ConfigurationType getValue_of_configuratio_type();

	/**
	 * Sets the value of the '{@link cams2024.ConcretSensor#getValue_of_configuratio_type <em>Value of configuratio type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value of configuratio type</em>' attribute.
	 * @see cams2024.ConfigurationType
	 * @see #getValue_of_configuratio_type()
	 * @generated
	 */
	void setValue_of_configuratio_type(ConfigurationType value);

	/**
	 * Returns the value of the '<em><b>Execution Type</b></em>' attribute.
	 * The literals are from the enumeration {@link cams2024.ExecutionType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Execution Type</em>' attribute.
	 * @see cams2024.ExecutionType
	 * @see #setExecutionType(ExecutionType)
	 * @see cams2024.Cams2024Package#getConcretSensor_ExecutionType()
	 * @model
	 * @generated
	 */
	ExecutionType getExecutionType();

	/**
	 * Sets the value of the '{@link cams2024.ConcretSensor#getExecutionType <em>Execution Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Execution Type</em>' attribute.
	 * @see cams2024.ExecutionType
	 * @see #getExecutionType()
	 * @generated
	 */
	void setExecutionType(ExecutionType value);

} // ConcretSensor
