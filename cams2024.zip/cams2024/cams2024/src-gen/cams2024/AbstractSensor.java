/**
 */
package cams2024;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link cams2024.AbstractSensor#getSensorType <em>Sensor Type</em>}</li>
 *   <li>{@link cams2024.AbstractSensor#getCorresponds_to_concretsensor <em>Corresponds to concretsensor</em>}</li>
 * </ul>
 *
 * @see cams2024.Cams2024Package#getAbstractSensor()
 * @model
 * @generated
 */
public interface AbstractSensor extends EObject {
	/**
	 * Returns the value of the '<em><b>Sensor Type</b></em>' attribute.
	 * The literals are from the enumeration {@link cams2024.SensorType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sensor Type</em>' attribute.
	 * @see cams2024.SensorType
	 * @see #setSensorType(SensorType)
	 * @see cams2024.Cams2024Package#getAbstractSensor_SensorType()
	 * @model
	 * @generated
	 */
	SensorType getSensorType();

	/**
	 * Sets the value of the '{@link cams2024.AbstractSensor#getSensorType <em>Sensor Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sensor Type</em>' attribute.
	 * @see cams2024.SensorType
	 * @see #getSensorType()
	 * @generated
	 */
	void setSensorType(SensorType value);

	/**
	 * Returns the value of the '<em><b>Corresponds to concretsensor</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.ConcretSensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Corresponds to concretsensor</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getAbstractSensor_Corresponds_to_concretsensor()
	 * @model containment="true"
	 * @generated
	 */
	EList<ConcretSensor> getCorresponds_to_concretsensor();

} // AbstractSensor
