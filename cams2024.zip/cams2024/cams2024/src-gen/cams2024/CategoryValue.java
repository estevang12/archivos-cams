/**
 */
package cams2024;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Category Value</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link cams2024.CategoryValue#getValue_of_categ <em>Value of categ</em>}</li>
 * </ul>
 *
 * @see cams2024.Cams2024Package#getCategoryValue()
 * @model
 * @generated
 */
public interface CategoryValue extends EObject {
	/**
	 * Returns the value of the '<em><b>Value of categ</b></em>' attribute.
	 * The default value is <code>"User"</code>.
	 * The literals are from the enumeration {@link cams2024.Categ_value}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value of categ</em>' attribute.
	 * @see cams2024.Categ_value
	 * @see #setValue_of_categ(Categ_value)
	 * @see cams2024.Cams2024Package#getCategoryValue_Value_of_categ()
	 * @model default="User"
	 * @generated
	 */
	Categ_value getValue_of_categ();

	/**
	 * Sets the value of the '{@link cams2024.CategoryValue#getValue_of_categ <em>Value of categ</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value of categ</em>' attribute.
	 * @see cams2024.Categ_value
	 * @see #getValue_of_categ()
	 * @generated
	 */
	void setValue_of_categ(Categ_value value);

} // CategoryValue
