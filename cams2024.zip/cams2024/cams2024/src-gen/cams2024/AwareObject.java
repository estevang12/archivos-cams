/**
 */
package cams2024;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Aware Object</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link cams2024.AwareObject#getName <em>Name</em>}</li>
 *   <li>{@link cams2024.AwareObject#getHas_contextfeature <em>Has contextfeature</em>}</li>
 *   <li>{@link cams2024.AwareObject#getBelong_categoryvalue <em>Belong categoryvalue</em>}</li>
 * </ul>
 *
 * @see cams2024.Cams2024Package#getAwareObject()
 * @model
 * @generated
 */
public interface AwareObject extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see cams2024.Cams2024Package#getAwareObject_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link cams2024.AwareObject#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Has contextfeature</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.ContextFeature}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Has contextfeature</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getAwareObject_Has_contextfeature()
	 * @model containment="true"
	 * @generated
	 */
	EList<ContextFeature> getHas_contextfeature();

	/**
	 * Returns the value of the '<em><b>Belong categoryvalue</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.CategoryValue}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Belong categoryvalue</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getAwareObject_Belong_categoryvalue()
	 * @model containment="true"
	 * @generated
	 */
	EList<CategoryValue> getBelong_categoryvalue();

} // AwareObject
