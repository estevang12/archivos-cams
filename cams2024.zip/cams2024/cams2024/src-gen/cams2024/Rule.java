/**
 */
package cams2024;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rule</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link cams2024.Rule#getExecutes <em>Executes</em>}</li>
 *   <li>{@link cams2024.Rule#getRule_description <em>Rule description</em>}</li>
 *   <li>{@link cams2024.Rule#getUpdate <em>Update</em>}</li>
 * </ul>
 *
 * @see cams2024.Cams2024Package#getRule()
 * @model
 * @generated
 */
public interface Rule extends EObject {
	/**
	 * Returns the value of the '<em><b>Executes</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Executes</em>' reference.
	 * @see #setExecutes(Service)
	 * @see cams2024.Cams2024Package#getRule_Executes()
	 * @model
	 * @generated
	 */
	Service getExecutes();

	/**
	 * Sets the value of the '{@link cams2024.Rule#getExecutes <em>Executes</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Executes</em>' reference.
	 * @see #getExecutes()
	 * @generated
	 */
	void setExecutes(Service value);

	/**
	 * Returns the value of the '<em><b>Rule description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rule description</em>' attribute.
	 * @see #setRule_description(String)
	 * @see cams2024.Cams2024Package#getRule_Rule_description()
	 * @model
	 * @generated
	 */
	String getRule_description();

	/**
	 * Sets the value of the '{@link cams2024.Rule#getRule_description <em>Rule description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rule description</em>' attribute.
	 * @see #getRule_description()
	 * @generated
	 */
	void setRule_description(String value);

	/**
	 * Returns the value of the '<em><b>Update</b></em>' reference list.
	 * The list contents are of type {@link cams2024.ContextFeature}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Update</em>' reference list.
	 * @see cams2024.Cams2024Package#getRule_Update()
	 * @model
	 * @generated
	 */
	EList<ContextFeature> getUpdate();

} // Rule
