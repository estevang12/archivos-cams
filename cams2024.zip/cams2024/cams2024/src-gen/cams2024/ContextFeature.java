/**
 */
package cams2024;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Context Feature</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link cams2024.ContextFeature#getObserver <em>Observer</em>}</li>
 *   <li>{@link cams2024.ContextFeature#getName <em>Name</em>}</li>
 *   <li>{@link cams2024.ContextFeature#getLatitud <em>Latitud</em>}</li>
 *   <li>{@link cams2024.ContextFeature#getLongitud <em>Longitud</em>}</li>
 *   <li>{@link cams2024.ContextFeature#getHas_abstractsensor <em>Has abstractsensor</em>}</li>
 *   <li>{@link cams2024.ContextFeature#getHas_relevancevalue <em>Has relevancevalue</em>}</li>
 * </ul>
 *
 * @see cams2024.Cams2024Package#getContextFeature()
 * @model
 * @generated
 */
public interface ContextFeature extends EObject {
	/**
	 * Returns the value of the '<em><b>Observer</b></em>' reference list.
	 * The list contents are of type {@link cams2024.Rule}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Observer</em>' reference list.
	 * @see cams2024.Cams2024Package#getContextFeature_Observer()
	 * @model required="true"
	 * @generated
	 */
	EList<Rule> getObserver();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see cams2024.Cams2024Package#getContextFeature_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link cams2024.ContextFeature#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Latitud</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Latitud</em>' attribute.
	 * @see #setLatitud(double)
	 * @see cams2024.Cams2024Package#getContextFeature_Latitud()
	 * @model default="0.0"
	 * @generated
	 */
	double getLatitud();

	/**
	 * Sets the value of the '{@link cams2024.ContextFeature#getLatitud <em>Latitud</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Latitud</em>' attribute.
	 * @see #getLatitud()
	 * @generated
	 */
	void setLatitud(double value);

	/**
	 * Returns the value of the '<em><b>Longitud</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Longitud</em>' attribute.
	 * @see #setLongitud(double)
	 * @see cams2024.Cams2024Package#getContextFeature_Longitud()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.Double"
	 * @generated
	 */
	double getLongitud();

	/**
	 * Sets the value of the '{@link cams2024.ContextFeature#getLongitud <em>Longitud</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Longitud</em>' attribute.
	 * @see #getLongitud()
	 * @generated
	 */
	void setLongitud(double value);

	/**
	 * Returns the value of the '<em><b>Has abstractsensor</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.AbstractSensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Has abstractsensor</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getContextFeature_Has_abstractsensor()
	 * @model containment="true"
	 * @generated
	 */
	EList<AbstractSensor> getHas_abstractsensor();

	/**
	 * Returns the value of the '<em><b>Has relevancevalue</b></em>' containment reference list.
	 * The list contents are of type {@link cams2024.RelevanceValue}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Has relevancevalue</em>' containment reference list.
	 * @see cams2024.Cams2024Package#getContextFeature_Has_relevancevalue()
	 * @model containment="true"
	 * @generated
	 */
	EList<RelevanceValue> getHas_relevancevalue();

} // ContextFeature
