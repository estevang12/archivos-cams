/**
 */
package cams2024;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see cams2024.Cams2024Package
 * @generated
 */
public interface Cams2024Factory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Cams2024Factory eINSTANCE = cams2024.impl.Cams2024FactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Metamodel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Metamodel</em>'.
	 * @generated
	 */
	Metamodel createMetamodel();

	/**
	 * Returns a new object of class '<em>Aware Object</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Aware Object</em>'.
	 * @generated
	 */
	AwareObject createAwareObject();

	/**
	 * Returns a new object of class '<em>Context Feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Context Feature</em>'.
	 * @generated
	 */
	ContextFeature createContextFeature();

	/**
	 * Returns a new object of class '<em>Abstract Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Abstract Sensor</em>'.
	 * @generated
	 */
	AbstractSensor createAbstractSensor();

	/**
	 * Returns a new object of class '<em>Relevance Value</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Relevance Value</em>'.
	 * @generated
	 */
	RelevanceValue createRelevanceValue();

	/**
	 * Returns a new object of class '<em>Category Value</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Category Value</em>'.
	 * @generated
	 */
	CategoryValue createCategoryValue();

	/**
	 * Returns a new object of class '<em>Rule</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Rule</em>'.
	 * @generated
	 */
	Rule createRule();

	/**
	 * Returns a new object of class '<em>Concret Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Concret Sensor</em>'.
	 * @generated
	 */
	ConcretSensor createConcretSensor();

	/**
	 * Returns a new object of class '<em>Presition Margin Value</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Presition Margin Value</em>'.
	 * @generated
	 */
	PresitionMarginValue createPresitionMarginValue();

	/**
	 * Returns a new object of class '<em>Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Service</em>'.
	 * @generated
	 */
	Service createService();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	Cams2024Package getCams2024Package();

} //Cams2024Factory
